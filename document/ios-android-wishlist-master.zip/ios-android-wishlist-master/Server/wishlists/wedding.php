<html>
	<head prefix="og: http://ogp.me/ns# YOUR_APP_NAMESPACE: http://ogp.me/ns/fb/YOUR_APP_NAMESPACE#">
    <meta property="fb:app_id"         content="YOUR_APP_ID">
    <meta property="og:url"           content="https://YOUR_HEROKU_SERVER_URL/wishlists/wedding.php">
    <meta property="og:type"           content="YOUR_APP_NAMESPACE:wishlist">
    <meta property="og:title"          content="Wedding Wishlist">
    <meta property="og:description"    content="Congratulations on tying the knot!">
    <meta property="og:image"          content="http://site.goweddinggifts.com/blog/wp-content/uploads/2011/08/gwg6.jpg">
    <meta property="YOUR_APP_NAMESPACE:id" content="3">
		<title></title>
	</head>
	<body>
	</body>
</html>
