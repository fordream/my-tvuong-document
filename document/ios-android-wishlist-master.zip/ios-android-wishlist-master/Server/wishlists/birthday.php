<html>
	<head prefix="og: http://ogp.me/ns# YOUR_APP_NAMESPACE: http://ogp.me/ns/fb/YOUR_APP_NAMESPACE#">
    <meta property="fb:app_id"         content="YOUR_APP_ID">
    <meta property="og:url"           content="https://YOUR_HEROKU_SERVER_URL/wishlists/birthday.php">
    <meta property="og:type"           content="YOUR_APP_NAMESPACE:wishlist">
    <meta property="og:title"          content="Birthday Wishlist">
    <meta property="og:description"    content="Happy Birthday to you, Happy Birthday to you!">
    <meta property="og:image"          content="http://images.pictureshunt.com/pics/h/happy_birthday_candles-2010.jpg">
    <meta property="YOUR_APP_NAMESPACE:id" content="1">
		<title></title>
	</head>
	<body>
	</body>
</html>
