<html>
	<head prefix="og: http://ogp.me/ns# YOUR_APP_NAMESPACE: http://ogp.me/ns/fb/YOUR_APP_NAMESPACE#">
    <meta property="fb:app_id"         content="YOUR_APP_ID">
    <meta property="og:url"           content="https://YOUR_HEROKU_SERVER_URL/wishlists/holiday.php">
    <meta property="og:type"           content="YOUR_APP_NAMESPACE:wishlist">
    <meta property="og:title"          content="Holiday Wishlist">
    <meta property="og:description"    content="Happy Holidays!">
    <meta property="og:image"          content="http://crazy-frankenstein.com/free-wallpapers-files/christmas-tree-wallpapers/beautiful-christmas-tree.jpg">
    <meta property="YOUR_APP_NAMESPACE:id" content="2">
		<title></title>
	</head>
	<body>
	</body>
</html>
