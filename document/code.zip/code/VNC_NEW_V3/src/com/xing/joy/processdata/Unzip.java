package com.xing.joy.processdata;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import android.os.AsyncTask;

public class Unzip extends AsyncTask<FilesModel, Integer, Boolean> {

	protected long total = 0;

	/** BUFFER read file. */
	private static final int BUFFER = 2048;

	@Override
	protected Boolean doInBackground(FilesModel... params) {
		File mDirectory = new File(params[0].getPathDir());
		File tmpFileConfig = null;
		if (!mDirectory.exists()) {
			mDirectory.mkdirs();
		}
		for (FilesModel filesModel : params) {
			// UNZIP file.
			try {
				File file = new File(filesModel.getUrl());
				ZipFile zip = new ZipFile(file);
				Enumeration<? extends ZipEntry> zipFileEntries = zip.entries();
				// Process each entry.
				while (zipFileEntries.hasMoreElements()) {

					// grab a ZIP file entry.
					ZipEntry entry = (ZipEntry) zipFileEntries.nextElement();
					String currentEntry = entry.getName();
					if (currentEntry.contains(".ini")) {
						currentEntry = currentEntry.replace(".ini", ".tmp");
					}
					File destFile = new File(filesModel.getPathDir(),
							currentEntry);
					if (currentEntry.contains(".tmp")) {
						tmpFileConfig = destFile;
					}
					File destinationParent = destFile.getParentFile();

					// create the parent directory structure if needed.
					destinationParent.mkdirs();

					if (!entry.isDirectory()) {
						BufferedInputStream is = new BufferedInputStream(
								zip.getInputStream(entry));
						int currentByte;
						// establish buffer for writing file
						byte data[] = new byte[BUFFER];

						// write the current file to disk.
						FileOutputStream fos = new FileOutputStream(destFile);
						BufferedOutputStream dest = new BufferedOutputStream(
								fos, BUFFER);
						// read and write until last byte is encountered.
						while ((currentByte = is.read(data, 0, BUFFER)) != -1) {
							total += currentByte;
							publishProgress(1000);
							dest.write(data, 0, currentByte);
						}
						dest.flush();
						dest.close();
						is.close();
					}
				}
				if(tmpFileConfig != null){
					tmpFileConfig.renameTo(new File(tmpFileConfig.getAbsolutePath().replace(".tmp", ".ini")));
				}
				// Delete ZIP file.
				file.delete();
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}

}
