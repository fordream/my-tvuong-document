/**
 * 
 */
package com.xing.joy.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import jp.co.xing.utaehon.R;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.IBinder;
import android.util.Log;

import com.ict.library.common.CommonLog;

/**
 * @author truongvv
 * 
 */
public class ToolSevice extends Service implements Runnable {

	/**
	 * 
	 */
	public ToolSevice() {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Service#onBind(android.content.Intent)
	 */
	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		new Thread(this).start();
		return super.onStartCommand(intent, flags, startId);
	}

	// Check Internet Connection
	public boolean isOnline() {
		ConnectivityManager conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo info = conMgr.getActiveNetworkInfo();
		if (info != null && info.isConnected()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void run() {
		while (!isRestricted()) {

			String url_post = getString(R.string.url_log_time);
			if (Logtime.isEnable) {
				if (Logtime.sampleDB != null && isOnline()) {
					Logtime logtime = new Logtime(this);

					// get information time
					String DATA_LOG_TIME = logtime.LogTotalPageGetall();

					if (!DATA_LOG_TIME.equalsIgnoreCase("")) {
						CommonLog.e("TIME DATA", DATA_LOG_TIME);
						try {
							// send data to server
							DefaultHttpClient httpclient = new DefaultHttpClient();

							HttpPost httppost = new HttpPost(url_post);

							httppost.setHeader("Content-type",
									"application/json");

							StringEntity se = new StringEntity(DATA_LOG_TIME,
									"UTF-8");

							se.setContentEncoding((Header) new BasicHeader(
									HTTP.CONTENT_TYPE, "application/json"));

							httppost.setEntity(se);
							HttpResponse response = httpclient
									.execute(httppost);

							HttpEntity entity = response.getEntity();
							InputStream is = entity.getContent();

							// Delete data
							if (getDataFromResponse(is)) {
								logtime.LogPageDeleteAll();
							}
						} catch (Exception e) {
						}
					}
				}
			}

			try {
				Thread.sleep(10 * 1000);
			} catch (InterruptedException e) {
			}
		}
	}

	private boolean getDataFromResponse(InputStream is) {

		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		String line = null;
		try {
			String return_ = "";
			while ((line = reader.readLine()) != null) {
				return_ = line;
			}
			if (!return_.equalsIgnoreCase("")) {
				Log.e("TEST===2", return_);
				try {
					JSONObject json = new JSONObject(return_);
					JSONArray nameArray = json.names();
					JSONArray valArray = json.toJSONArray(nameArray);
					for (int i = 0; i < valArray.length(); i++) {
						if (nameArray.getString(i).endsWith("status")
								&& valArray.getString(i).endsWith("OK")) {
							return true;
						}
					}
				} catch (JSONException e) {
					e.printStackTrace();
				}
			} else {
			}
		} catch (IOException e) {
		}

		return false;
	}
}