package jp.co.xing.utaehon;

import android.app.Application;
import android.content.Intent;
import android.util.Log;

import com.xing.joy.service.ToolSevice;
import jp.co.xing.utaehon.R;

public class JoysoundApplication extends Application {

	@Override
	public void onCreate() {
		Log.d("TEST", "JoysoundApplication");
		super.onCreate();
		startService(new Intent(this, ToolSevice.class));
	}
}