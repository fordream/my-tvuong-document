/**
 * 
 */
package com.vnp.loader.img;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.view.View;

/**
 * 
 */
public class ImageClientLoader {
	public static ImageClientLoader instance;
	private Context context;
	private MemoryCache memoryCache = new MemoryCache();
	private FileCache fileCache;

	public static ImageClientLoader getInstance() {
		if (instance == null) {
			instance = new ImageClientLoader(null);
		}

		return instance;
	}

	public void init(Context context) {
		this.context = context;
		fileCache = new FileCache(context);
	}

	private ImageClientLoader(Context context) {
		this.context = context;
	}

	public Bitmap getBitmap(String path) {
		try {
			Bitmap bitmap = memoryCache.get(path);
			if (bitmap != null) {
				if (!bitmap.isRecycled()) {
					return bitmap;
				}
			}

			BitmapFactory.Options o = new BitmapFactory.Options();
			o.inJustDecodeBounds = true;
			BitmapFactory.decodeFile(path, o);
			// Find the correct scale value. It should be the power of 2.
			final int REQUIRED_SIZE = 480;
			int width_tmp = o.outWidth, height_tmp = o.outHeight;
			int scale = 1;
			while (true) {
				if (width_tmp / 2 < REQUIRED_SIZE
						|| height_tmp / 2 < REQUIRED_SIZE)
					break;
				width_tmp /= 2;
				height_tmp /= 2;
				scale *= 2;
			}
			BitmapFactory.Options o2 = new BitmapFactory.Options();
			o2.inSampleSize = scale;

			bitmap = BitmapFactory.decodeFile(path, o2);

			if (bitmap != null) {
				memoryCache.put(path, bitmap);
			}
			return bitmap;
		} catch (Throwable e) {
			if (e instanceof OutOfMemoryError) {
				release();
			}
		}
		return null;
	}

	public Bitmap getBitmap(int res) {
		try {
			Bitmap bitmap = memoryCache.get(res + "");
			if (bitmap != null) {
				return bitmap;
			}

			BitmapFactory.Options o2 = new BitmapFactory.Options();
			// o2.inSampleSize = scale;

			bitmap = BitmapFactory.decodeResource(context.getResources(), res,
					o2);

			if (bitmap != null) {
				memoryCache.put(res + "", bitmap);
			}
			return bitmap;
		} catch (Throwable exception) {
			if (exception instanceof OutOfMemoryError) {
				release();
			}
		}

		return null;
	}

	public void release() {
		memoryCache.clear();
		fileCache.clear();
	}

	public void createDrawable(final int res, final View view) {
		Bitmap bitmap = getBitmap(res);
		view.setBackgroundDrawable(new BitmapDrawable(bitmap));
	}
}