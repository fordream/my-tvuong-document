package jp.co.xing.utaehon03.util;

import jp.naver.KDTCUE.R;
import android.content.Context;

public class UrlUtils {
	private Context context;

	public UrlUtils(Context context) {
		this.context = context;
	}

	private String getServer() {
		String server_config = context.getResources().getString(
				R.string.server_config);
		if (server_config.equals("1")) {
			return context.getResources().getString(R.string.server_test_local);
		} else if (server_config.equals("2")) {
			return context.getResources().getString(
					R.string.server_test_internet);
		} else if (server_config.equals("3")) {
			return context.getResources().getString(R.string.server_real);
		}

		return context.getResources().getString(R.string.server_real);
	}

	public String getUrl(int res) {

		String folderServer = context.getResources().getString(res);

		if (folderServer.startsWith("http://")) {
			return folderServer;
		}

		return getServer() + context.getResources().getString(res);
	}
}
