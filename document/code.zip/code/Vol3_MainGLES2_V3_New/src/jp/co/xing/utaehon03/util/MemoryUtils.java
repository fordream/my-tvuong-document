package jp.co.xing.utaehon03.util;

import java.io.File;
import java.io.IOException;

import android.content.Context;
import android.os.Environment;
import android.os.StatFs;

/**
 * This class for process with SDCard.
 * */
public class MemoryUtils {

	private String pathFileExternalMemory = "";
	private String pathCacheExternalMemory = "";
	private String pathFileInternalMemory = "";

	/** 1MB block. */
	private static final int MB = 1048576;

	public MemoryUtils(Context context) {
		super();

		String path = "/Android/data/";
		// path = "/MAndroid/data/";
		pathFileExternalMemory = Environment.getExternalStorageDirectory()
				+ path + context.getPackageName() + "/files/";
		pathCacheExternalMemory = Environment.getExternalStorageDirectory()
				+ path + context.getPackageName() + "/cache/";
		pathFileInternalMemory = context.getFilesDir().getPath() + "/";
	}

	public String getPathFileExternalMemory() {
		return pathFileExternalMemory;
	}

	public String getPathCacheExternalMemory() {
		return pathCacheExternalMemory;
	}

	public String getPathFileInternalMemory() {
		return pathFileInternalMemory;
	}

	public boolean checkSDAvaiable(String path) {
		boolean isSDCardExisted = false;
		if (!new File(path).exists()) {
			new File(path).mkdirs();
		}
		File file = new File(path, "test" + System.currentTimeMillis() + ".txt");
		try {
			isSDCardExisted = file.createNewFile();
		} catch (IOException e1) {
			isSDCardExisted = false;
		}
		file.delete();
		return isSDCardExisted;
	}

	public double checkSDFreeMB() {

		if (!checkSDAvaiable(getPathCacheExternalMemory())) {
			return 0;
		} else {
			StatFs stat = new StatFs(getPathCacheExternalMemory());
			double sdAvailSize = (double) stat.getAvailableBlocks()
					* (double) stat.getBlockSize();

			return sdAvailSize / MB;
		}
	}

	public boolean isSDCardExisted() {
		return !(checkSDFreeMB() == 0);
	}
}
