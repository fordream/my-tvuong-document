package jp.co.xing.utaehon.v2;

import android.app.Application;

import com.vnp.loader.img.ImageClientLoader;

public class JoysoundApplication extends Application {

	@Override
	public void onCreate() {
		super.onCreate();
		ImageClientLoader.getInstance().init(this);
	}
}