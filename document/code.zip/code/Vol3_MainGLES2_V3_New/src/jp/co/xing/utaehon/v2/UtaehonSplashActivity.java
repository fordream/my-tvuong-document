package jp.co.xing.utaehon.v2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import jp.co.xing.utaehon03.util.CommonUtils;
import jp.co.xing.utaehon03.util.ConfigApp;
import jp.naver.KDTCUE.R;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager.NameNotFoundException;
import android.media.AudioManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import com.ict.library.database.DataStore;
import com.xing.joy.interfaces.IDataActions;
import com.xing.joy.others.BaseInappActivity;
import com.xing.joy.others.BuyActivity;
import com.xing.joy.others.TopActivity;

public class UtaehonSplashActivity extends BaseInappActivity {
	/** Tag log. */
	private static final String LOG_STARTUP = UtaehonSplashActivity.class
			.getName();

	/** Image splash screen. */
	private ImageView imgSplashScreen;
	private ImageView imgGetActionBar;

	/** Runnable waite . */
	private Runnable runnaSplashScreen;
	/** check update log time */
	private static boolean check_update_log_time = false;
	private static boolean ResponseLogTime = false;
	private static String DATA_LOG_TIME = "";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.d(LOG_STARTUP, "Startup");

		// Set control Media Volume
		setVolumeControlStream(AudioManager.STREAM_MUSIC);

		setContentView(R.layout.startup);

		imgSplashScreen = (ImageView) findViewById(R.id.flashscreen);
		imgGetActionBar = (ImageView) findViewById(R.id.getActionBar);

		resizeView(imgSplashScreen, 0, 0, 0, 0);
		resizeView(imgGetActionBar, 0, 0, 0, 0);

		imgGetActionBar.setBackgroundResource(0);

		// AutoCreateShortCut
		CommonUtils.autoCreateShortCut(
				appData.getBoolData(IDataActions.IS_SHORTCUT), this);

		appData.setBoolData(IDataActions.IS_SHORTCUT, true);

		// get all log time
		DATA_LOG_TIME = "";

		// TODO tool
		if (ConfigApp.ISENABLE_LOGTIME) {
			try {
				if (logtime.sampleDB != null && isOnline()) {
					Log.e("Startup:getlogtime==OK:", "onload");
					check_update_log_time = true;
					ResponseLogTime = false;
					DATA_LOG_TIME = logtime.LogTotalPageGetall();
					if (!DATA_LOG_TIME.equalsIgnoreCase("")) {

						new Thread(getDataLogTime).start();
						Log.e("Startup:getlogtime==OK:", DATA_LOG_TIME);
					} else {
						check_update_log_time = true;
					}
				} else {
					check_update_log_time = true;
					Log.e("Startup:getlogtime==NG:", "null");
				}
			} catch (Exception e) {
				check_update_log_time = true;
				Log.e("Startup:getlogtime==NG:", "abc");
			}
		}
	}

	private Runnable getDataLogTime = new Runnable() {

		@Override
		public void run() {
			try {

				String param = DATA_LOG_TIME;// "{\"pass\":\"LjeIiJPJTaA=\" , \"device\": \"android\",\"user_id\":\"199999991\",\"data\":[{\"page_id\":\"page_id_1\",\"date\":\"2013-01-02\",\"count\":10,\"playtime\":3600},{\"page_id\":\"page_id_1\",\"date\":\"2013-01-03\",\"count\":15,\"playtime\":25}]}";
				// CredentialsProvider credProvider = new
				// BasicCredentialsProvider();
				// credProvider.setCredentials(new AuthScope(AuthScope.ANY_HOST,
				// AuthScope.ANY_PORT), new UsernamePasswordCredentials(
				// getString(R.string.url_user),
				// getString(R.string.url_password)));
				// "http://157.7.162.27/vol3general/test1.php";
				DefaultHttpClient httpclient = new DefaultHttpClient();
				// httpclient.setCredentialsProvider(credProvider);
				String url_post = getString(R.string.url_log_time);
				HttpPost httppost = new HttpPost(url_post);
				Log.e("post url==", url_post);
				Log.e("post data==", param);
				httppost.setHeader("Content-type", "application/json");
				StringEntity se = new StringEntity(param, "UTF-8");
				se.setContentEncoding((Header) new BasicHeader(
						HTTP.CONTENT_TYPE, "application/json"));
				httppost.setEntity(se);
				HttpResponse response = httpclient.execute(httppost);
				HttpEntity entity = response.getEntity();
				InputStream is = entity.getContent();
				getDataFromResponse(is);
				// //Logtime.LogPageDeleteAll();
				// startNextActivity();

			} catch (Exception e) {
				// startNextActivity();
				// e.printStackTrace();
			}
		}
	};

	private void getDataFromResponse(InputStream is) {

		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		String line = null;
		try {
			String return_ = "";
			while ((line = reader.readLine()) != null) {
				return_ = line;
			}
			if (!return_.equalsIgnoreCase("")) {
				Log.e("TEST===2", return_);
				try {
					JSONObject json = new JSONObject(return_);
					JSONArray nameArray = json.names();
					JSONArray valArray = json.toJSONArray(nameArray);
					for (int i = 0; i < valArray.length(); i++) {
						if (nameArray.getString(i).endsWith("status")
								&& valArray.getString(i).endsWith("OK")) {
							ResponseLogTime = true;
						}
					}
					if (ResponseLogTime) {
						// update DB log time
						Log.e("TEST===ResponseLogTime", "=OK");
						logtime.LogPageDeleteAll();
						check_update_log_time = true;
						// startNextActivity();
					} else {
						Log.e("TEST===ResponseLogTime", "=NG");
						check_update_log_time = true;
						// startNextActivity();
					}
				} catch (JSONException e) {
					Log.e("TEST===4", return_);
					check_update_log_time = true;
					// startNextActivity();
					e.printStackTrace();
				}

			} else {
				Log.e("TEST===Response:NULL=", return_);
			}
			// check_update_log_time = true;
		} catch (IOException e) {
			Log.e("TEST===5", "error");
			// startNextActivity();
			e.printStackTrace();
		}
	}

	private void confirmRegisterWithC2DM() {
		final AlertDialog alertDialog = new AlertDialog.Builder(this).create();
		alertDialog.setMessage(getString(R.string.allow_push));
		alertDialog.setCancelable(false);
		alertDialog.setCanceledOnTouchOutside(false);

		alertDialog.setButton2(this.getString(R.string.btn_no),
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						// alertDialog.dismiss();
						isConfirmGCM(false);
					}
				});

		alertDialog.setButton(this.getString(R.string.btn_yes),
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						// alertDialog.dismiss();
						// TODO
						isConfirmGCM(true);
						// isConfirmGCM(false);
					}
				});

		if (this.hasWindowFocus()) {
			alertDialog.show();
		}
	}

	private void isConfirmGCM(boolean isOK) {
		try {
			if (isOK) {
				appData.setStringData("AllowReceivePush", "yes");
			} else {
				appData.setStringData("AllowReceivePush", "no");
			}

			CommonUtils.registerGCM(isOK, getApplicationContext());
		} catch (Exception e) {
		}

		startNextActivity();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	protected void onResume() {
		if (imgSplashScreen != null) {
			if (appData.getStringData(IDataActions.CLASS_NAME).contains(
					"com.xing.joy.others.Buy")
					&& appData.getIntData(IDataActions.PROCESS_ID) == android.os.Process
							.myPid()) {
				CommonUtils.startNewActivity(this, BuyActivity.class, "");
			} else {
				runnaSplashScreen = new Runnable() {
					@Override
					public void run() {
						if (appData.getStringData("AllowReceivePush")
								.equalsIgnoreCase("")) {
							confirmRegisterWithC2DM();
						} else {
							if (appData.getStringData("AllowReceivePush")
									.equalsIgnoreCase("yes")) {
								CommonUtils.registerGCM(true,
										getApplicationContext());
							}

							// if (check_update_log_time) {
							startNextActivity();
							// }
							// startNextActivity();
						}
					}
				};

				imgSplashScreen.postDelayed(runnaSplashScreen, 1500);
			}
		}
		super.onResume();
		countDownload();
	}

	private void countDownload() {
		DataStore.getInstance().init(this);
		String keyName = "_now_version_name";
		int versionCode = DataStore.getInstance().get(keyName, 0);

		int versionCodeOfApp = -1;
		try {
			versionCodeOfApp = this.getPackageManager().getPackageInfo(
					this.getPackageName(), 0).versionCode;
		} catch (NameNotFoundException e) {
		}

		if (versionCode != versionCodeOfApp && versionCodeOfApp != -1) {
			// if (isOnline()) {
			// Log.e(keyName, versionCode + "  " + versionCodeOfApp);
			// update version
			if (versionCode != 0) {
				// UPDATE
				if (versionCodeOfApp > versionCode) {
					 Log.e(keyName, "UPDATE");
					String category = getResources().getString(
							R.string.namescreen_count_update);
					String action = "";
					String label = "";
					gauTils.sendEvent(category, action, label);
				}
			} else {
				// download version
				// NEW DOWNLOAD
				 Log.e(keyName, "NEW DOWNLOAD");
				String category = getResources().getString(
						R.string.namescreen_count_downnload);
				String action = "";
				String label = "";
				gauTils.sendEvent(category, action, label);
			}

			DataStore.getInstance().save(keyName, versionCodeOfApp);
			// }
		}
	}

	@Override
	public void showPushNotification() {
		// Rewite and Nothing
	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		if (appData.getIntData(IDataActions.HEIGHT_BAR) == 0) {
			appData.setIntData(IDataActions.HEIGHT_BAR,
					calResize.getHeight() - imgGetActionBar.getHeight() - 2
							* calResize.getHemBlackHeight());
		}
	}

	/**
	 * start activity Top, for show menu
	 */
	private void startNextActivity() {
		CommonUtils.startNewActivity(this, TopActivity.class, "");
	}

	@Override
	protected void onPause() {
		// if (imgSplashScreen != null) {
		imgSplashScreen.removeCallbacks(runnaSplashScreen);
		// imgSplashScreen.setBackgroundResource(0);
		// imgSplashScreen = null;
		// }
		// runnaSplashScreen = null;
		Log.d(LOG_STARTUP, "On Pause");
		finish();

		super.onPause();
	}

	@Override
	public void setBaseApplicationData() {
		return;
	}

	@Override
	protected void onIabPurchaseFinish(boolean failure, String sku) {
		// TODO Auto-generated method stub

	}

	@Override
	public String getNameCount() {
		// return "";
		return getResources().getString(R.string.namescreen_splash);
	}
}