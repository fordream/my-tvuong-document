package jp.co.xing.utaehon03.util;

public class ConfigApp {

	// Cho phep hien thi web view hay khong
	public static final boolean CAN_SHOW_WEBVIEW = true;

	// cho phep tinh nang tinh thoi gian logtime
	// cho phep cong thoi gian va ghi vao data base
	public static final boolean ISENABLE_LOGTIME = false;

	// cho phep moi lan vao app se tu dong gui len server tool
	// true la chec do debug voi time gia
	public static final boolean DEBUG_LOG_LOGTIME = false;

	// bat che do debug cho ung dung
	// debug la true se luon hien thi cac bai da down load va hien thi
	// redownload
	public static final boolean ISDEBUGAPP = true;

}