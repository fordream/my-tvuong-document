package com.xing.joy.others.zzz;

import android.content.Context;
import android.view.View;

/**
 * Class for gender a view by compare input
 * 
 * 
 */
public class Gender {
	/** Context for generate view */
	private Context context;

	/** data for generate view */
	private Object obj;

	public Gender(Context context, Object object) {
		super();
		this.context = context;
		this.obj = object;
	}

	/*
	 * by obj to create a view
	 */
	public View generate() {
		View view = null;

		return view;
	}
}