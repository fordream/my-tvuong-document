package com.xing.joy.processdata;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import android.os.AsyncTask;

import com.xing.joy.others.zzz.ZUnzip;
import com.xing.joy.others.zzz.Zlog;

public class Unzip extends AsyncTask<FilesModel, Integer, Boolean> {

	protected long total = 0;

	/** BUFFER read file. */
	private int BUFFER = 2048;

	// private static final int BUFFER = 2 ^ 16;

	// private static final int BUFFER = 2^14;
	@Override
	protected Boolean doInBackground(FilesModel... params) {
		File mDirectory = new File(params[0].getPathDir());
		if (!mDirectory.exists()) {
			mDirectory.mkdirs();
		}

		for (FilesModel filesModel : params) {
			// UNZIP file.
			File file = new File(filesModel.getUrl());
			try {
				// File file = new File(filesModel.getUrl());
				ZipFile zip = new ZipFile(file);
				Enumeration<? extends ZipEntry> zipFileEntries = zip.entries();
				// Process each entry.
				while (zipFileEntries.hasMoreElements()) {

					// grab a ZIP file entry.
					ZipEntry entry = (ZipEntry) zipFileEntries.nextElement();
					String currentEntry = entry.getName();

					Zlog.e(Unzip.class.getName(), currentEntry);

					File destFile = new File(filesModel.getPathDir(),
							currentEntry);
					File destinationParent = destFile.getParentFile();

					// create the parent directory structure if needed.
					destinationParent.mkdirs();

					if (!entry.isDirectory()) {
						BufferedInputStream is = new BufferedInputStream(
								zip.getInputStream(entry));
						int currentByte; // establish buffer for writing file

						int file_size = (int) entry.getCompressedSize();
						Zlog.e("file==: ", "" + file_size);
						FileOutputStream fos = new FileOutputStream(destFile);
						
						
						byte data[] = null;
						BufferedOutputStream dest = null;
						
						
						/*
						try {
							BUFFER = file_size;
							data = new byte[BUFFER]; // write the current
														// file to disk.

							dest = new BufferedOutputStream(fos, BUFFER); // read
																			// and
																			// write
																			// until
																			// last
																			// byte
																			// is
																			// encountered.
						} catch (OutOfMemoryError e) {

							BUFFER = 2048;
							data = new byte[BUFFER]; // write the current
							// file to disk.
							dest = new BufferedOutputStream(fos, BUFFER); // read
																			// and
																			// write
																			// until
																			// last
																			// byte
																			// is
																			// encountered.
						}
						
						*/
						
						data = new ZUnzip(null).data(file_size);
						BUFFER = data.length;
						
						Zlog.e("resize ==: ", "" + BUFFER);
//						dest = new BufferedOutputStream(fos);
						
						
						dest = new BufferedOutputStream(fos, BUFFER);

						
						while ((currentByte = is.read(data, 0, BUFFER)) != -1) {
							total += currentByte;
							publishProgress(1000);
							dest.write(data, 0, currentByte);
						}
						
						dest.flush();
						dest.close();
						is.close();
					}

					// if (!entry.isDirectory()) {
					// BufferedInputStream is = new BufferedInputStream(
					// zip.getInputStream(entry));
					// int currentByte;
					// // establish buffer for writing file
					// byte data[] = new byte[BUFFER];
					//
					// // write the current file to disk.
					// FileOutputStream fos = new FileOutputStream(destFile);
					// BufferedOutputStream dest = new BufferedOutputStream(
					// fos, BUFFER);
					//
					// // read and write until last byte is encountered.
					// while ((currentByte = is.read(data, 0, BUFFER)) != -1) {
					// total += currentByte;
					// publishProgress(1000);
					// dest.write(data, 0, currentByte);
					// }
					//
					// dest.flush();
					// dest.close();
					// is.close();
					// }
				}
				// Delete ZIP file.
				file.delete();

				// delete(params, file);
			} catch (Exception e) {
				// if unzip is fail
				// delete id
				// delete
				// delete(params, file);
				// delete file zip

				Zlog.e(Unzip.class.getName(), e);
				return false;
			}
		}
		return true;
	}
}
