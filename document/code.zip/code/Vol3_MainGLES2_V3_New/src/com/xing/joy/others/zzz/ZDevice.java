package com.xing.joy.others.zzz;

import java.util.List;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.util.DisplayMetrics;

public class ZDevice {
	private Context context;

	public ZDevice(Context context) {
		this.context = context;
	}

	public boolean haveMailAccountOnDevice() {
		AccountManager accountManager = AccountManager.get(context);
		Account account = getAccount(accountManager);

		return account != null;
	}

	private Account getAccount(AccountManager accountManager) {
		Account[] accounts = accountManager.getAccountsByType("com.google");
		Account account;
		if (accounts.length > 0) {
			account = accounts[0];
		} else {
			account = null;
		}
		return account;
	}

	/**
	 * Check Device is Tablet or not, return true if your device is Tablet,
	 * return false if Phone.
	 * 
	 * @return boolean
	 * */
	public boolean isTablet() {
		try {
			DisplayMetrics metrics = context.getResources().getDisplayMetrics();
			float screenWidth = (metrics.widthPixels / metrics.xdpi)
					* metrics.density;
			float screenHeight = (metrics.heightPixels / metrics.ydpi)
					* metrics.density;
			float tmp;
			if (metrics.widthPixels > metrics.heightPixels) {
				tmp = metrics.heightPixels * metrics.density;
			} else {
				tmp = metrics.widthPixels * metrics.density;
			}
			double size = Math.sqrt(Math.pow(screenWidth, 2)
					+ Math.pow(screenHeight, 2));
			return (size >= 6) && (tmp >= 400);
		} catch (Throwable t) {
			return false;
		}
	}

	public boolean isTabletLargeOrXlarge() {
		boolean xlarge = ((context.getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) == 4);
		boolean large = ((context.getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) == Configuration.SCREENLAYOUT_SIZE_LARGE);
		return (xlarge || large);
	}

	public boolean checkExistPackageOfApplication(String otherPackage) {
		PackageManager packageManager = (PackageManager) context
				.getPackageManager();

		boolean check = false;
		List<ApplicationInfo> packages = packageManager
				.getInstalledApplications(PackageManager.GET_META_DATA);

		for (ApplicationInfo packageInfo : packages) {
			Zlog.e("package", packageInfo.packageName);
			if (packageInfo.packageName.equals(otherPackage)) {
				check = true;
				//return check;
			}
		}

		return check;
	}
}