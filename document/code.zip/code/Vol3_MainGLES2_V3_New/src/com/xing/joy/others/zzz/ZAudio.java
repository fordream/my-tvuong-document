package com.xing.joy.others.zzz;

import android.app.Activity;
import android.content.Context;
import android.media.AudioManager;

public class ZAudio {
	private AudioManager mgr;

	public ZAudio(Context context) {
		mgr = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);

		((Activity) context).setVolumeControlStream(AudioManager.STREAM_MUSIC);
	}

	/**
	 * 
	 * @return value of volumn
	 */
	public float getVolumn() {
		float vlCurrent = mgr.getStreamVolume(AudioManager.STREAM_MUSIC);
		float vlMax = mgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
		return vlCurrent / vlMax;
	}

	/**
	 * status is AudioManager.ADJUST_LOWER when volumn down. status is
	 * AudioManager.ADJUST_RAISE when vloum up
	 * 
	 * @param status
	 */
	public void changleVolumn(int status) {
		mgr.adjustStreamVolume(AudioManager.STREAM_MUSIC, status,
				AudioManager.FLAG_SHOW_UI);
	}
}