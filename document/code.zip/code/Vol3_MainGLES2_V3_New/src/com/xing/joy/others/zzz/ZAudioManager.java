package com.xing.joy.others.zzz;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;

public class ZAudioManager {
	private Context context;
	/** Manager of audio. */
	private AudioManager audioManager;
	private MediaPlayer mediaPlayer;

	public ZAudioManager(Context context) {
		this.context = context;
		// Load AudioManager
		audioManager = (AudioManager) context
				.getSystemService(Context.AUDIO_SERVICE);

	}

	public float getStreamVolume() {
		return audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
	}

	public float getStreamMaxVolume() {
		return audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
	}

	public void startMediaPlayer(int res, boolean isLoop) {
		mediaPlayer = MediaPlayer.create(context, res);
		// mediaPlayer.setVolume(volume, volume);
		mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
		mediaPlayer.setLooping(isLoop);
	}

}