package com.xing.joy.others.zzz;

public class ZConfig {
	//public static final boolean TEST_BUY = true;
	//public static String id = "";
	public static final boolean BUY = false;

	public static final boolean NOT_PUBLICKKEY_CUSSOM =true;
}