package com.xing.joy.others.zzz;

import android.content.Context;
import android.content.SharedPreferences;

public class Zsetting {
	private SharedPreferences preferences;

	public Zsetting(Context context) {
		preferences = context.getSharedPreferences("Setting_Utaehon", 0);
	}

	public boolean isOpen() {
		return preferences.getBoolean("isPoen", false);
	}

	public void setOpen(boolean isOpen) {
		preferences.edit().putBoolean("isPoen", isOpen).commit();
	}
}