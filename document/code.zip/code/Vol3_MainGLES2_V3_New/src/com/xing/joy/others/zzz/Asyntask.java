/**
 * 
 */
package com.xing.joy.others.zzz;

import android.os.AsyncTask;

/**
 * 
 * 
 */
public class Asyntask extends AsyncTask<Object, Object, Object> {

	@Override
	protected Object doInBackground(Object... arg0) {
		return null;
	}

	@Override
	protected void onPostExecute(Object result) {
		super.onPostExecute(result);
	}

	@Override
	protected void onProgressUpdate(Object... values) {
		super.onProgressUpdate(values);
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
	}
}