package com.xing.joy.others.zzz;

import java.util.HashMap;

import android.util.Log;

/**
 * 
 * 
 */
public class Zlog {
	private HashMap<String, String> data = new HashMap<String, String>();

	public Zlog() {
		data.clear();
		data.put("Constance0", "");
		data.put("Constance1", "");
		data.put("Constance2", "");
		data.put("Constance3", "");
	}

	public static void e(String tag, String message) {
		Log.e(tag, "--------------------start----------------------------");
		Log.e(tag, message);
		Log.e(tag, "---------------------end-----------------------------");
	}

	public static void e(String name, Exception e) {
		Log.e(name, "--------------------start----------------------------");
		Log.e(name, "Error", e);
		Log.e(name, "---------------------end-----------------------------");
	}
}