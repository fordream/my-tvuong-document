/**
 * 
 */
package com.xing.joy.others.zzz.dialog;

import jp.naver.KDTCUE.R;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.xing.joy.others.zzz.ZClickSpan;

/**
 * 
 */

public class ZDialog extends Dialog implements
		android.view.View.OnClickListener {
	private String[] urls = new String[] {
			"https://kids.line.naver.jp/terms/ja/",
			"http://line.naver.jp/app/line_rules/ja/" };
	private Button bntSwap;
	private Button btnCancel;
	private Button btnAccepted;
	private WebView webView;
	private CallBack callBack;
	private ProgressBar progressBar;
	private TextView popUp_textView2;
	private boolean onErrorLoadPage = false;

	/**
	 * @param context
	 */
	public ZDialog(Context context, CallBack callBack) {
		super(context, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
		this.callBack = callBack;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

		setContentView(R.layout.arg);

		popUp_textView2 = (TextView) findViewById(R.id.popUp_textView2);

		bntSwap = (Button) findViewById(R.id.button3);
		btnCancel = (Button) findViewById(R.id.button1);
		btnAccepted = (Button) findViewById(R.id.button2);

		progressBar = (ProgressBar) findViewById(R.id.progressBar1);

		webView = (WebView) findViewById(R.id.webView1);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.setWebChromeClient(new WebChromeClient() {
			public void onProgressChanged(WebView view, int progress) {
				if (progress < 100) {
					progressBar.setVisibility(View.VISIBLE);
				} else {
					progressBar.setVisibility(View.GONE);
				}
			}
		});

		webView.setWebViewClient(new WebViewClient() {

			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				super.onPageStarted(view, url, favicon);
				btnAccepted.setEnabled(false);
				AlphaAnimation alphaAnimation = new AlphaAnimation(1f, 0.5f);
				alphaAnimation.setFillAfter(true);
				btnAccepted.startAnimation(alphaAnimation);

				bntSwap.setEnabled(false);
			}

			@Override
			public void onReceivedError(WebView view, int errorCode,
					String description, String failingUrl) {
				onErrorLoadPage = true;
				super.onReceivedError(view, errorCode, description, failingUrl);
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);

				bntSwap.setEnabled(true);
				if (!onErrorLoadPage) {
					btnAccepted.setEnabled(true);
					AlphaAnimation alphaAnimation = new AlphaAnimation(0.5f, 1f);
					alphaAnimation.setFillAfter(true);
					btnAccepted.startAnimation(alphaAnimation);
				}
			}
		});

		setCancelable(false);

		btnAccepted.setOnClickListener(this);
		btnCancel.setOnClickListener(this);
		bntSwap.setOnClickListener(this);

		ZClickSpan zClickSpan = new ZClickSpan();
		zClickSpan.addLink(popUp_textView2, getContext().getResources()
				.getString(R.string.dialog_link_text1),
				new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						onErrorLoadPage = false;
						bntSwap.setTag("0");
						swapUrl(bntSwap);
					}
				});

		popUp_textView2.append(getContext().getResources().getString(
				R.string.dialog_link_text_01));

		zClickSpan.addLink(popUp_textView2, getContext().getResources()
				.getString(R.string.dialog_link_text2),
				new View.OnClickListener() {

					@Override
					public void onClick(View v) {
						onErrorLoadPage = false;
						bntSwap.setTag("1");
						swapUrl(bntSwap);
					}
				});
		popUp_textView2.append(getContext().getResources().getString(
				R.string.dialog_link_text_02));
		popUp_textView2.setMovementMethod(LinkMovementMethod.getInstance());

	}

	@Override
	public void show() {
		super.show();
		bntSwap.setTag("0");
		swapUrl(bntSwap);
	}

	private void swapUrl(View view) {
		int index = 0;
		if (view.getTag().equals("1")) {
			index = 1;
		}

		webView.loadUrl(urls[index]);
	}

	@Override
	public void onClick(View view) {
		if (view == bntSwap) {
			dismiss();
			callBack.callback(true);
		} else if (view == btnAccepted) {
			dismiss();
			callBack.callback(false);
		} else if (view == btnCancel) {
			dismiss();
			callBack.callback(true);
		}
	}

	public interface CallBack {
		public void callback(boolean isCancel);
	}

}