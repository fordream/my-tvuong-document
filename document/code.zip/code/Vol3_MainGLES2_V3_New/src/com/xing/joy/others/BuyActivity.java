package com.xing.joy.others;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jp.co.xing.utaehon03.util.CommonUtils;
import jp.naver.KDTCUE.R;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.xing.joy.common.DownloadProgessBar;
import com.xing.joy.common.PackageSongs;
import com.xing.joy.interfaces.IDataActions;
import com.xing.joy.others.zzz.IInterface;
import com.xing.joy.others.zzz.ZConfig;
import com.xing.joy.others.zzz.ZUnzip;
import com.xing.joy.others.zzz.Zlog;
import com.xing.joy.processdata.Download;
import com.xing.joy.processdata.FilesModel;
import com.xing.joy.processdata.ReportHistory;
import com.xing.joy.processdata.Unzip;

/**
 * This activity for display purchase screen.
 **/
public class BuyActivity extends BaseInappActivity implements OnClickListener,
		IInterface {

	/** Tag log name. */
	private static final String TAG = BuyActivity.class.getSimpleName();

	/** View id=CONST_ID+packageID. */
	private static final int CONST_ID = 1500;

	/** List all packages that show in Buy Screen. */
	private List<PackageSongs> packageSongs = new ArrayList<PackageSongs>();

	/** Position of 6 songs in one page. */
	private int[][] coor = { { 250, 30 }, { 580, 30 }, { 250, 230 },
			{ 580, 230 }, { 250, 430 }, { 580, 430 } };
	/** Image Slide. */
	private ImageView imgSlide;

	/** Image information. */
	private ImageView imgInfo;

	/** Image cancel information. */
	private ImageView imgCancelInfo;

	/** Temporary ImageView storing the Icon of Package which is clicked. */
	private static ImageView purchasedImage;

	/** Image for buy button. */
	private ImageView imgBuy = null;
	private ImageView imgCancel = null;

	/** Image for download button. */
	private ImageView imgDownload;

	/** Image for button displayed when Download OK. */
	private ImageView imgOK;
	/** Image for button displayed when history. */
	private ImageView imgHistory;

	/** Unknown purpose. */
	private AnimationDrawable aniDrawSwitchSingle;

	/** Total of all pages in scroll. */
	private int totalPage = 0;
	private int currentPage = 0;

	/** Purchase package when user select. */
	private String purchasedPackage = null;

	/** Shared preference file name to store purchase result. */
	private static final String PURCHASED_DB = "purchased_db";

	/** Share Preference for purchase_db. */
	private SharedPreferences prefs = null;

	/** Download ProgressBar X close button. */
	private ImageView mProgressCloseX;

	/** Text on Download ProgressBar */
	private TextView page;
	private ViewPager pager;
	private DownloadProgessBar downloadBar;
	private DownloadSongPackage dlPackage;

	private PackagesPagerAdapter packagesAdapter;

	private Map<String, String> listSongDateModifier = new HashMap<String, String>();
	private ArrayList<RelativeLayout> listPage = new ArrayList<RelativeLayout>();
	private SongPackageUnzip spUnzip;

	private class PackagesPagerAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			if (packageSongs != null) {
				totalPage = packageSongs.size() / SIZE_6;
				if (packageSongs.size() % SIZE_6 != 0) {
					totalPage += 1;
				}
			}
			return totalPage;
		}

		@Override
		public Object instantiateItem(View collection, int position) {
			RelativeLayout layout = createOnPage(position, packageSongs);
			((ViewPager) collection).addView(layout, 0);
			return layout;
		}

		@Override
		public void destroyItem(View collection, int position, Object view) {
			RelativeLayout tmp = (RelativeLayout) view;
			for (int i = 0; i < tmp.getChildCount(); i++) {
				setNullViewDrawable((ImageView) tmp.getChildAt(i));
			}
			tmp.removeAllViews();
			tmp = null;
			((ViewPager) collection).removeView((RelativeLayout) view);
		}

		@Override
		public boolean isViewFromObject(View view, Object object) {
			return view == ((RelativeLayout) object);
		}

		@Override
		public void finishUpdate(View arg0) {
		}

		@Override
		public void restoreState(Parcelable arg0, ClassLoader arg1) {
		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View arg0) {
		}

	}

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {

		// Create hem image.
		setContentView(R.layout.buy);
		super.onCreate(savedInstanceState);
		createHemImage(R.id.buy_display);

		// Initial shared preferences.
		prefs = getApplication().getSharedPreferences(PURCHASED_DB,
				MODE_PRIVATE);

		imgSlide = (ImageView) findViewById(R.id.slider);
		resizeView(imgSlide, 0, 0, 0, 0);
		setBacgroundResource(imgSlide, R.drawable.sideber_iphone_);

		imgInfo = (ImageView) findViewById(R.id.info);

		resizeView(imgInfo, 0, 0, 0, 0);
		imgBuy = (ImageView) findViewById(R.id.ok_info);
		resizeView(imgBuy, 485, 510, 0, 0);
		imgDownload = (ImageView) findViewById(R.id.dl_btn);
		resizeView(imgDownload, 485, 510, 0, 0);
		imgOK = (ImageView) findViewById(R.id.ok_download);
		resizeView(imgOK, 388, 510, 0, 0);
		imgCancelInfo = (ImageView) findViewById(R.id.cancel_info);
		resizeView(imgCancelInfo, 285, 510, 0, 0);
		mProgressCloseX = (ImageView) findViewById(R.id.close_x_btn);
		resizeView(mProgressCloseX, 898, 0, 0, 0);
		imgCancel = (ImageView) findViewById(R.id.canceldownload);
		resizeView(imgCancel, 425, 558, 0, 0);

		// setting action
		imgInfo.setOnClickListener(null);
		imgBuy.setOnClickListener(this);
		imgDownload.setOnClickListener(this);
		imgCancelInfo.setOnClickListener(this);
		mProgressCloseX.setOnClickListener(this);
		imgOK.setOnClickListener(this);

		imgCancel.setOnTouchListener(cancelDownload);

		imgBuy.setEnabled(ZConfig.BUY);

		new Thread(getDateModifierPackBought).start();

		if (!isSDCardExisted()) {
			Toast.makeText(getApplicationContext(),
					getString(R.string.no_sdcard), Toast.LENGTH_LONG).show();
		}

		ImageView imgBackground = (ImageView) findViewById(R.id.imgBackGround);
		// imgBackground.setBackgroundResource(R.drawable.a1_18_iphone_buy_haikei);
		resizeView(imgBackground, 0, 0, 0, 0);
		setBacgroundResource(imgBackground, R.drawable.a1_18_iphone_buy_haikei);

		pager = (ViewPager) findViewById(R.id.awesomepager);
		// pager.setBackgroundResource(R.drawable.a1_18_iphone_buy_haikei);
		resizeView(pager, 0, 0, 0, 0);
		setBacgroundResource(pager, R.drawable.a1_18_iphone_buy_haikei);

		pager.setOnPageChangeListener(new OnPageChangeListener() {
			@Override
			public void onPageSelected(int arg0) {
				currentPage = arg0;
				page.setText((arg0 + 1) + "/" + totalPage + " "
						+ getString(R.string.page));
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {

			}

			@Override
			public void onPageScrollStateChanged(int arg0) {

			}
		});

		page = (TextView) findViewById(R.id.help_text);
		resizeView(page, 505, 600, 0, 0);
		page.setTextColor(Color.rgb(102, 51, 0));
		try {
			Typeface font = Typeface.createFromFile(this.getFilesDir()
					.toString() + "/a_otf_jun501pro_bold.otf");
			page.setTypeface(font);
		} catch (Exception e) {
			e.printStackTrace();
		}

		addBackButton(R.id.buy_display);

		imgHistory = (ImageView) findViewById(R.id.buy_img_history);
		showImgHistory(true);

		resizeView(imgHistory, 35, 508, 0, 0);
		setBacgroundResource(imgHistory, R.drawable.aiueo_off_iphone);

		packageSongs.addAll(parsePackageInfoXML());
		changeModeDisplay();

		imgInfo.setVisibility(View.GONE);
	}

	@Override
	protected void onStop() {
		super.onStop();
		// logtime.Logend(Logtime.PAGE_BUYPACKAGE);
	}

	@Override
	protected void onStart() {
		super.onStart();
		// logtime.Logstart(Logtime.PAGE_BUYPACKAGE);
		// logtime.LogPageStart = Logtime.PAGE_BUYPACKAGE;

		imgInfo.postDelayed(new Runnable() {
			@Override
			public void run() {
				if (!isBillingSupported()) {
					showDialog(DIALOG_CANNOT_CONNECT_ID);
				}
			}
		}, 1000);
	}

	private OnTouchListener cancelDownload = new OnTouchListener() {
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			try {
				if (imgCancel != null
						&& imgCancel.getVisibility() == View.VISIBLE) {
					if (dlPackage != null) {
						dlPackage.cancel(true);
						dlPackage = null;
					}

					com.xing.joy.processdata.Download.isCancelled = true;
					downloadBar.reset();
					downloadBar.setVisibility(View.GONE);
					imgCancel.setVisibility(View.GONE);
					imgCancel.setEnabled(true);
					imgCancelInfo.setEnabled(true);

					imgBuy.setVisibility(View.GONE);
					imgDownload.setVisibility(View.VISIBLE);
					imgDownload.setAlpha(255);
					imgCancel.setAlpha(255);
					imgCancelInfo.setAlpha(255);
					imgCancelInfo.setEnabled(true);
					mProgressCloseX.setAlpha(255);

					imgCancelInfo.setVisibility(View.VISIBLE);
					isTouch = true;
				}
			} catch (Exception e) {
			}
			return true;
		}
	};

	private Runnable getDateModifierPackBought = new Runnable() {

		@Override
		public void run() {
			try {
				Map<String, ?> listSongBought = prefs.getAll();
				List<NameValuePair> values = new ArrayList<NameValuePair>();
				for (Map.Entry<String, ?> entry : listSongBought.entrySet()) {
					if (entry.getKey().contains("jp.co.xing")
							|| entry.getKey().contains("free.song.relation")) {
						values.add(new BasicNameValuePair("pack[]", entry
								.getKey()));
					}
				}
				if (values.size() <= 0) {
					return;
				}
				values.add(new BasicNameValuePair("device_id", CommonUtils
						.findDeviceID(BuyActivity.this)));
				CredentialsProvider credProvider = new BasicCredentialsProvider();
				credProvider.setCredentials(new AuthScope(AuthScope.ANY_HOST,
						AuthScope.ANY_PORT), new UsernamePasswordCredentials(
						getString(R.string.url_user),
						getString(R.string.url_password)));
				DefaultHttpClient httpclient = new DefaultHttpClient();
				httpclient.setCredentialsProvider(credProvider);
//				String pathFile = getString(R.string.url_package_download);
				String pathFile = urlUtils.getUrl(R.string.url_package_download);
				if (isTablet()) {
//					pathFile = getString(R.string.url_package_hd_download);
					 pathFile = urlUtils.getUrl(R.string.url_package_hd_download);
				}
				HttpPost httppost = new HttpPost(pathFile
						+ "checkLastUpdate.php");
				httppost.setEntity(new UrlEncodedFormEntity(values));
				// Execute HTTP Post Request
				HttpResponse response = httpclient.execute(httppost);
				HttpEntity entity = response.getEntity();
				InputStream is = entity.getContent();
				getDataFromResponse(is);
				listSongBought.clear();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	};

	private void getDataFromResponse(InputStream is) {

		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				String[] info = line.split("#");
				listSongDateModifier.put(info[0], info[1]);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		if (hasFocus) {
			if (aniDrawSwitchSingle != null) {
				aniDrawSwitchSingle.start();
			}
			if (page != null) {
				int sizePage = page.getHeight() / 2;
				if (sizePage < 20) {
					sizePage = 20;
				}
				if (sizePage > 40) {
					sizePage = 40;
				}
				page.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizePage);
				page.setText((currentPage + 1) + "/" + totalPage + " "
						+ getString(R.string.page));
			}
		}
	}

	public void changeModeDisplay() {
		if (listPage != null) {
			for (Iterator<RelativeLayout> getPage = listPage.iterator(); getPage
					.hasNext();) {
				RelativeLayout page = (RelativeLayout) getPage.next();
				for (int i = 0; i < page.getChildCount(); i++) {
					setNullViewDrawable((ImageView) page.getChildAt(i));
				}
				page.clearDisappearingChildren();
				page.removeAllViews();
				page.removeAllViewsInLayout();
			}
			listPage.clear();
		}
		calculateTotalPage();
		packagesAdapter = null;
		packagesAdapter = new PackagesPagerAdapter();
		pager.setAdapter(packagesAdapter);

		pager.setCurrentItem(currentPage, false);

		if (page != null) {
			page.setText((currentPage + 1) + "/" + totalPage + " "
					+ getString(R.string.page));
		}

		pager.setBackgroundResource(0);
	}

	public RelativeLayout createOnPage(int position, List<PackageSongs> packages) {

		RelativeLayout onPage = new RelativeLayout(this);

		resizeViewInView(onPage, 960, 640, 0, 0, 0, 0);
		setBacgroundResource(onPage, R.drawable.a1_18_iphone_buy_haikei);
		int countPackage = SIZE_6 * position;
		for (int j = 0; j < SIZE_6; j++) {
			String path = "";
			try {
				path = memory.getPathFileInternalMemory() + "img_buy/"
						+ packages.get(countPackage).getIconImage();
			} catch (Exception e) {
			}

			// Bitmap bmImg = BitmapFactory.decodeFile(path);
			Bitmap bmImg = imageClientLoader.getBitmap(path);
			Drawable d = new BitmapDrawable(bmImg);

			ImageView imgPackageButton = new ImageView(this);
			imgPackageButton.setBackgroundDrawable(d);
			String packageName = "";
			try {
				packageName = packages.get(countPackage).getPackageName();
			} catch (Exception e) {
			}

			if (isPurchased(packageName) || isDebug()) {
				if (haveContent(packageName)) {
					imgPackageButton.getBackground().setAlpha(100);
				} else {
					imgPackageButton.getBackground().setAlpha(255);
				}
			} else {
				imgPackageButton.getBackground().setAlpha(255);
			}

			int id = CONST_ID + packages.get(countPackage).getPackageID();

			imgPackageButton.setId(id);

			resizeViewInView(imgPackageButton, 317, 166, coor[j][0],
					coor[j][1], 0, 0);

			imgPackageButton.setOnClickListener(this);

			packages.get(countPackage).setImage(imgPackageButton);

			onPage.addView(imgPackageButton);

			countPackage++;

			if (countPackage >= packages.size()) {
				break;
			}
		}

		listPage.add(onPage);
		return onPage;

	}

	@Override
	public void onClick(View view) {
		if (isDownloadingOrUnziping()) {
			return;
		}
		page.setVisibility(View.INVISIBLE);

		if (view != imgBuy && view != imgDownload) {
			imgInfo.setVisibility(View.GONE);
		}

		boolean isPurchased = false;

		for (Iterator<PackageSongs> iterator = packageSongs.iterator(); iterator
				.hasNext();) {
			PackageSongs ps = (PackageSongs) iterator.next();
			if (view.getId() == ps.getPackageID() + CONST_ID) {
				isPurchased = processPackagePurchased(ps);
				showImgHistory(false);
				break;
			}
		}

		if (view == mProgressCloseX) {
			imgCancelInfo.setVisibility(View.GONE);
			imgBuy.setVisibility(View.GONE);
			imgDownload.setVisibility(View.GONE);
			mProgressCloseX.setVisibility(View.GONE);
			imgOK.setVisibility(View.GONE);
			imgBack.setVisibility(View.VISIBLE);
			imgBuy.setEnabled(ZConfig.BUY);
			purchasedPackage = null;
			page.setVisibility(View.VISIBLE);

			showImgHistory(true);
		} else if (view == imgCancelInfo && imgCancelInfo.isEnabled()) {
			imgCancelInfo.setVisibility(View.GONE);
			imgBuy.setVisibility(View.GONE);
			imgDownload.setVisibility(View.GONE);
			mProgressCloseX.setVisibility(View.GONE);
			// setNullViewDrawable(imgInfo);
			imgOK.setVisibility(View.GONE);
			imgBack.setVisibility(View.VISIBLE);
			imgBuy.setEnabled(ZConfig.BUY);
			purchasedPackage = null;
			page.setVisibility(View.VISIBLE);

			showImgHistory(true);
		} else if (view == imgOK) {
			changeModeDisplay();
			// imgInfo.setOnTouchListener(null);
			imgOK.setVisibility(View.GONE);
			imgBuy.setVisibility(View.GONE);
			imgDownload.setVisibility(View.GONE);
			mProgressCloseX.setVisibility(View.GONE);
			imgBack.setVisibility(View.VISIBLE);
			page.setVisibility(View.VISIBLE);
			imgBuy.setEnabled(ZConfig.BUY);
			purchasedPackage = null;
			showImgHistory(true);
		} else if (view == imgBuy) {

			if (!isPurchased) {
				Log.d(TAG, "Clicked Buy Button for buy:" + purchasedPackage);
				launchPurchaseFlow(purchasedPackage);
			} else {
				Log.d(TAG, "Already bought song");
			}
			// Disable Buy and Cancel button after Buy button is clicked.
			imgBuy.setEnabled(ZConfig.BUY);
			imgBuy.setAlpha(50);
			imgCancelInfo.setEnabled(false);
			imgCancelInfo.setAlpha(50);
			mProgressCloseX.setEnabled(false);
			mProgressCloseX.setAlpha(50);
			isTouch = false;
		} else if (view == imgDownload) {
			Zlog.e(BuyActivity.class.getName(), purchasedPackage);
			dlPackage = (DownloadSongPackage) new DownloadSongPackage(
					BuyActivity.this).execute();
		}
	}

	private void showImgHistory(boolean b) {
		imgHistory.setVisibility(b ? View.VISIBLE : View.GONE);
		imgHistory.setVisibility(View.GONE);

	}

	/**
	 * This method used for calculate number of pages loaded.
	 * */
	private void calculateTotalPage() {

		// calculate number pages.
		totalPage = PackageSongs.packageSongs / SIZE_6;
		if (PackageSongs.packageSongs % SIZE_6 > 0) {
			totalPage += 1;
		}

		if (totalPage == 0) {
			totalPage = 1;
		}
	}

	/**
	 * This method used for detect status of song package. By purchase status
	 * and setup status to setup UI.
	 * 
	 * @param ps
	 *            {@link PackageSongs}Package to process.
	 * @return {@link Boolean} Result package installed or not.
	 * */
	private boolean processPackagePurchased(PackageSongs ps) {

		purchasedPackage = ps.getPackageName();
		purchasedImage = ps.getImage();

		mProgressCloseX.setImageResource(R.drawable.close_btn_adr4);
		mProgressCloseX.setVisibility(View.VISIBLE);
		mProgressCloseX.setAlpha(255);

		mProgressCloseX.setEnabled(true);
		imgBack.setVisibility(View.GONE);

		// background dialog
		String path = memory.getPathFileInternalMemory() + "img_buy/"
				+ ps.getImageInfo();

		Bitmap bmImg = imageClientLoader.getBitmap(path);

		imgInfo.setImageBitmap(bmImg);
		imgInfo.setVisibility(View.VISIBLE);

		imgBuy.setEnabled(true);
		imgBuy.setAlpha(255);

		if (!isSDCardExisted() || !isSportInappV3) {
			imgBuy.setAlpha(50);
			imgBuy.setEnabled(false);
		}

		if (isPurchased(purchasedPackage) || isDebug()) {
			if (haveContent(purchasedPackage)) {
				imgOK.setVisibility(View.VISIBLE);
				if (purchasedPackage.contains("free.song.relation")) {
					// imgOK.setBackgroundResource(R.drawable.dlok_bt_iphone);

					setBacgroundResource(imgOK, R.drawable.dlok_bt_iphone);
				} else {
					// imgOK.setBackgroundResource(R.drawable.buy_ok);
					setBacgroundResource(imgOK, R.drawable.buy_ok);
				}
				imgCancelInfo.setVisibility(View.GONE);
				imgCancelInfo.setEnabled(false);
				imgBuy.setEnabled(false);
				imgBuy.setVisibility(View.GONE);
			} else {
				imgCancelInfo.setImageResource(R.drawable.cancel_iphone);
				imgCancelInfo.setVisibility(View.VISIBLE);
				imgCancelInfo.setEnabled(true);
				imgBuy.setVisibility(View.GONE);
				imgBuy.setEnabled(false);
				imgDownload.setVisibility(View.VISIBLE);
				imgCancelInfo.setVisibility(View.VISIBLE);
			}
		} else {
			imgCancelInfo.setImageResource(R.drawable.cancel_iphone);
			imgCancelInfo.setVisibility(View.VISIBLE);
			imgCancelInfo.setEnabled(true);

			imgBuy.setImageResource(R.drawable.buy_iphone);
			imgBuy.setEnabled(true);
			imgBuy.setAlpha(255);

			imgBuy.setVisibility(View.VISIBLE);
		}

		if (!isBillingSupported()) {
			imgBuy.setEnabled(false);
			imgBuy.setAlpha(100);
		}

		return isPurchased(purchasedPackage);
	}

	@Override
	public void releaseMemory() {
		if (listPage != null) {
			for (Iterator<RelativeLayout> getPage = listPage.iterator(); getPage
					.hasNext();) {
				RelativeLayout page = (RelativeLayout) getPage.next();
				for (int i = 0; i < page.getChildCount(); i++) {
					setNullViewDrawable((ImageView) page.getChildAt(i));
				}
				page.clearDisappearingChildren();
				page.removeAllViews();
				page.removeAllViewsInLayout();
				page.setBackgroundResource(0);
				page.removeAllViews();
				page.destroyDrawingCache();
				page.setBackgroundDrawable(null);
				page.setBackgroundResource(0);
				page = null;
			}
			listPage.clear();
		}
		if (page != null) {
			page.setText("");
			page = null;
		}
		if (imgOK != null) {
			setNullViewDrawable(imgOK);
		}
		if (imgCancelInfo != null) {
			setNullViewDrawable(imgCancelInfo);
		}
		if (mProgressCloseX != null) {
			setNullViewDrawable(mProgressCloseX);
		}
		if (imgBuy != null) {
			setNullViewDrawable(imgBuy);
		}
		if (imgDownload != null) {
			setNullViewDrawable(imgDownload);
		}
		if (imgInfo != null) {
			setNullViewDrawable(imgInfo);
		}
		if (imgSlide != null) {
			setNullViewDrawable(imgSlide);
		}
		if (imgCancel != null) {
			setNullViewDrawable(imgCancel);
			imgCancel = null;
		}
		imgDownload = null;
		imgCancelInfo = null;
		mProgressCloseX = null;
		imgOK = null;
		imgBuy = null;
		imgInfo = null;
		imgSlide = null;

		packageSongs = null;
		coor = null;
		aniDrawSwitchSingle = null;
		purchasedPackage = null;
		packagesAdapter = null;
		pager = null;
		super.releaseMemory();
	}

	private boolean isDownloadingOrUnziping() {
		return (dlPackage != null || spUnzip != null);
	}

	@Override
	public void onBackPressed() {
		// while download return

		if (isDownloadingOrUnziping()) {
			return;
		}
		// while infor show
		if (isShowView(imgInfo)) {
			changeModeDisplay();
			imgInfo.setVisibility(View.GONE);
			imgCancelInfo.setVisibility(View.GONE);

			imgOK.setVisibility(View.GONE);
			imgBuy.setVisibility(View.GONE);
			imgDownload.setVisibility(View.GONE);
			mProgressCloseX.setVisibility(View.GONE);
			imgBack.setVisibility(View.VISIBLE);
			page.setVisibility(View.VISIBLE);
			imgBuy.setEnabled(false);
			purchasedPackage = null;
			showImgHistory(true);
			return;
		}

		try {
			releaseMemory();
			Bundle extras = getIntent().getExtras();
			if (extras.getString("Back") != null
					&& extras.getString("Back").equalsIgnoreCase("SelectSong")) {
				CommonUtils
						.startNewActivity(this, SelectSongActivity.class, "");
			} else {
				CommonUtils.startNewActivity(this, TopActivity.class, "");
			}
		} catch (Exception e) {
			CommonUtils.startNewActivity(this, TopActivity.class, "");
		} finally {
		}

		super.onBackPressed();
	}

	@Override
	protected void onUserLeaveHint() {
		appData.setIntData(IDataActions.PROCESS_ID, android.os.Process.myPid());
	}

	private class DownloadSongPackage extends Download {

		@Override
		protected void onPreExecute() {
			isTouch = false;
			if (downloadBar == null) {
				downloadBar = (DownloadProgessBar) findViewById(R.id.download_bar);
				DownloadProgessBar.typeDataDownload = 1;
				resizeView(downloadBar, 163, 425, 0, 0);
			}

			downloadBar.setVisibility(View.VISIBLE);
			imgCancel.setVisibility(View.VISIBLE);
			mProgressCloseX.setAlpha(100);
			imgCancelInfo.setVisibility(View.INVISIBLE);
			imgDownload.setVisibility(View.INVISIBLE);
			super.onPreExecute();
		}

		protected Boolean doInBackground(FilesModel... params) {
			// download file
			FilesModel[] fm = new FilesModel[1];
			
//			String pathFile = getString(R.string.url_package_download);
			String pathFile = urlUtils.getUrl(R.string.url_package_download);
			if (isTablet()) {
//				pathFile = getString(R.string.url_package_hd_download);
				pathFile = urlUtils.getUrl(R.string.url_package_hd_download);
			}

			fm[0] = new FilesModel(purchasedPackage + ".zip", pathFile
					+ "download.php?package=" + purchasedPackage,
					memory.getPathCacheExternalMemory());

			return super.doInBackground(fm[0]);
		}

		@Override
		public void onProgressUpdate(Integer... args) {
			if (args[0] != null) {
				downloadBar.updateProgessBar(args[0]);
			}
		}

		public DownloadSongPackage(Context context) {
			super(context, true);
		}

		@Override
		protected void onPostExecute(Boolean result) {
			if (result != null && result) {
				FilesModel[] fm = new FilesModel[1];
				fm[0] = new FilesModel(purchasedPackage + ".zip",
						memory.getPathCacheExternalMemory() + purchasedPackage
								+ ".zip", memory.getPathFileExternalMemory());
				DownloadProgessBar.STATUS_DOWNLOAD = getString(R.string.dlp_unzip);
				downloadBar.invalidate();

				spUnzip = (SongPackageUnzip) new SongPackageUnzip().execute(fm);

				HttpClient httpclient = new DefaultHttpClient();
//				HttpPost httppost = new HttpPost(
//						getString(R.string.url_top_free_download)
//								+ "download.php");
				
				HttpPost httppost = new HttpPost(
						urlUtils.getUrl(R.string.url_top_free_download)
								+ "download.php");
				try {
					// Add your data
					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
							2);
					nameValuePairs.add(new BasicNameValuePair("device",
							Build.DEVICE));
					nameValuePairs.add(new BasicNameValuePair("product",
							Build.PRODUCT));
					nameValuePairs.add(new BasicNameValuePair("model",
							Build.MODEL));
					nameValuePairs.add(new BasicNameValuePair("manufacturer",
							Build.MANUFACTURER));
					nameValuePairs.add(new BasicNameValuePair("os_version",
							Build.VERSION.RELEASE));
					nameValuePairs.add(new BasicNameValuePair("device_id",
							Build.ID));
					nameValuePairs.add(new BasicNameValuePair("imei",
							CommonUtils.findDeviceID(BuyActivity.this)));
					nameValuePairs.add(new BasicNameValuePair(
							"product_item_id", purchasedPackage));
					httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					Log.d("TEST", nameValuePairs.toString());
					// Send request
					httpclient.execute(httppost);
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				downloadBar.setVisibility(View.GONE);
				imgCancel.setVisibility(View.GONE);
				downloadBar.reset();
				imgBuy.setVisibility(View.GONE);
				imgDownload.setVisibility(View.VISIBLE);
				imgCancelInfo.setVisibility(View.VISIBLE);
				isTouch = true;
			}

			dlPackage = null;

			super.onPostExecute(result);
		}
	}

	private class SongPackageUnzip extends Unzip {

		@Override
		protected void onPreExecute() {
			try {
				imgCancel.setVisibility(View.GONE);
			} catch (Exception e) {
			}
		}

		@Override
		protected void onPostExecute(Boolean result) {
			try {
				if (result != null && result && imgOK != null) {
					imgBuy.setAlpha(255);
					imgCancelInfo.setAlpha(255);
					downloadBar.setVisibility(View.GONE);
					imgCancel.setVisibility(View.GONE);
					downloadBar.reset();
					// Disable buy button when finish buy and download.

					imgBuy.setVisibility(View.GONE);
					imgCancelInfo.setVisibility(View.GONE);
					imgDownload.setVisibility(View.GONE);
					Toast.makeText(BuyActivity.this,
							getString(R.string.dlp_dl_completed),
							Toast.LENGTH_LONG).show();
					ReportHistory report = new ReportHistory(BuyActivity.this);
					report.resetReportCountByPackage(purchasedPackage);
					if (purchasedPackage.contains("free.song.relation")) {
						SharedPreferences.Editor edit = prefs.edit();
						edit.putString(purchasedPackage,
								"true;" + System.currentTimeMillis());
						edit.commit();
					}

					imgOK.postDelayed(new Runnable() {
						@Override
						public void run() {
							if (imgOK != null && isShowView(imgInfo)) {
								imgOK.setVisibility(View.VISIBLE);
								if (purchasedPackage != null
										&& purchasedPackage
												.contains("free.song.relation")) {
									// imgOK.setBackgroundResource(R.drawable.dlok_bt_iphone);

									setBacgroundResource(imgOK,
											R.drawable.dlok_bt_iphone);
								} else {
									// imgOK.setBackgroundResource(R.drawable.buy_ok);

									setBacgroundResource(imgOK,
											R.drawable.buy_ok);
								}
								isTouch = true;
								mProgressCloseX.setAlpha(255);
								mProgressCloseX.setEnabled(true);
							}
						}
					}, 3000);

					purchasedImage.getBackground().setAlpha(100);
				} else {
					uinZipFail();
				}
			} catch (Exception e) {
				Zlog.e(BuyActivity.class.getName(), e);
			}

			spUnzip = null;
		}
	}

	private void uinZipFail() {
		try {
			ZUnzip zUnzip = new ZUnzip(this);
			zUnzip.deleteItemBuy(memory, purchasedPackage);
			downloadBar.setVisibility(View.GONE);

			setBacgroundResource(imgDownload, R.drawable.re_dl);

			imgDownload.setVisibility(View.VISIBLE);
			imgCancelInfo.setVisibility(View.VISIBLE);
			imgCancelInfo.setAlpha(255);
			isTouch = true;
		} catch (Exception exception) {
			Zlog.e(BuyActivity.class.getName(), exception);
		}
	}

	// ---------------------------------------------------
	// V3 INAPP
	// ---------------------------------------------------
	@Override
	protected void onIabPurchaseFinish(boolean failure, String sku) {

		if (!failure) {
			ReportHistory report = new ReportHistory(BuyActivity.this);
			report.increaseReportCountByPackage2(sku);
			imgCancelInfo.setEnabled(false);
			imgCancelInfo.setAlpha(100);
			mProgressCloseX.setEnabled(false);
			mProgressCloseX.setAlpha(50);

			dlPackage = (DownloadSongPackage) new DownloadSongPackage(
					BuyActivity.this).execute();

		} else {
			imgCancelInfo.setEnabled(true);
			imgCancelInfo.setAlpha(255);
			mProgressCloseX.setEnabled(true);
			mProgressCloseX.setAlpha(255);
		}

		imgBuy.setEnabled(true);
		imgBuy.setAlpha(255);

		isTouch = true;
	}

	@Override
	public String getNameCount() {
		// return Logtime.PAGE_BUYPACKAGE;
		return getResources().getString(R.string.namescreen_buy);
	}
}