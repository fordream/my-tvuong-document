package com.xing.joy.others;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import jp.co.xing.utaehon03.util.CommonUtils;
import jp.naver.KDTCUE.R;
import android.app.AlertDialog;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.xing.joy.common.DownloadProgessBar;
import com.xing.joy.common.Songs;
import com.xing.joy.interfaces.IDataActions;
import com.xing.joy.others.zzz.ZPath;
import com.xing.joy.others.zzz.ZUnzip;
import com.xing.joy.others.zzz.Zlog;
import com.xing.joy.others.zzz.Zparse;
import com.xing.joy.play.DynamicSongActivity;
import com.xing.joy.play.PlayMovieDynamicGameActivity;
import com.xing.joy.processdata.Download;
import com.xing.joy.processdata.FilesModel;
import com.xing.joy.processdata.Unzip;

public class SelectSongActivity extends BaseInappActivity implements
		OnTouchListener {
	private Handler handler = new Handler();
	private int totalPage = 0;
	private static int currentPage = 0;
	private static int currentTypeSort = 2;
	private ArrayList<String> arrListPackages = new ArrayList<String>();
	private ImageView imgSlide;
	private ImageView imgSortName;
	private ImageView imgSortOld;
	private ImageView imgSortNew;
	private ImageView imgBuyBt;
	private ImageView imgCancel;
	private AnimationDrawable draBuyBt;

	private ArrayList<Songs> lsong = new ArrayList<Songs>();
	private ArrayList<RelativeLayout> lpageSong = new ArrayList<RelativeLayout>();

	private int[] imgIdSlideDrawable = { R.drawable.haikei_karaoke_iphone,
			R.drawable.haikei_teasobi_iphone, R.drawable.haikei_uta_iphone };

	private int[] imgIdBackgroundDrawable = {
			R.drawable.a1_18_iphone_karaoke_haikei,
			R.drawable.a1_18_iphone_douga_haikei,
			R.drawable.a1_18_iphone_uta_haikei };

	private int[][] coorMovie = { { 250, 30 }, { 580, 30 }, { 250, 230 },
			{ 580, 230 }, { 250, 430 }, { 580, 430 } };

	private int[][] coorSong = { { 260, 30 }, { 480, 30 }, { 700, 30 },
			{ 260, 230 }, { 480, 230 }, { 700, 230 }, { 260, 430 },
			{ 480, 430 }, { 700, 430 } };

	private int iconsOnPage = 9;
	private TextView page;

	private DownloadProgessBar downloadBar;
	private SongFreeDataDownload songFreeDataDownload;
	private AlertDialog alertDialog;

	/** List all packages that show in Buy Screen. */
	private HashMap<String, Boolean> packageSongs = new HashMap<String, Boolean>();

	private ViewPager pager;
	private SongsPagerAdapter songsAdapter;
	private Timer timer;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// set isTouch
		isTouch = false;

		// get package to display
		new GetPackageInfo().execute();

		getBaseContext().getResources().updateConfiguration(
				new Configuration(), configMetric());

		setContentView(R.layout.select_song);

		ImageView imgBackground = (ImageView) findViewById(R.id.imgBackGround);
		setBacgroundResource(imgBackground,
				imgIdBackgroundDrawable[appData
						.getIntData(IDataActions.TYPE_ID)]);
		resizeView(imgBackground, 0, 0, 0, 0);

		createHemImage(R.id.select_display);

		if (appData.getStringData(IDataActions.TYPE_NAME).equalsIgnoreCase(
				"douga_clicked")) {
			iconsOnPage = 6;
		}

		imgSortName = (ImageView) findViewById(R.id.sort_name);
		resizeView(imgSortName, 16, 240, 0, 0);
		imgSortName.setOnTouchListener(this);

		imgSortOld = (ImageView) findViewById(R.id.sort_old);
		resizeView(imgSortOld, 16, 280, 0, 0);
		imgSortOld.setOnTouchListener(this);

		imgSortNew = (ImageView) findViewById(R.id.sort_new);
		resizeView(imgSortNew, 16, 320, 0, 0);
		imgSortNew.setOnTouchListener(this);

		setImageSort(currentTypeSort);

		imgBuyBt = (ImageView) findViewById(R.id.buy_bt);
		resizeView(imgBuyBt, 16, 380, 0, 0);
		imgBuyBt.setBackgroundResource(R.anim.selectsong_buy_bt);

		draBuyBt = (AnimationDrawable) imgBuyBt.getBackground();
		imgBuyBt.setOnTouchListener(this);

		imgSlide = (ImageView) findViewById(R.id.slider);
		resizeView(imgSlide, 0, 0, 0, 0);
		// imgSlide.setBackgroundResource(imgIdSlideDrawable[appData
		// .getIntData(IDataActions.TYPE_ID)]);
		setBacgroundResource(imgSlide,
				imgIdSlideDrawable[appData.getIntData(IDataActions.TYPE_ID)]);

		imgCancel = (ImageView) findViewById(R.id.canceldownload);
		resizeView(imgCancel, 425, 530, 0, 0);
		imgCancel.setOnTouchListener(cancelDownload);

		pager = (ViewPager) findViewById(R.id.awesomepager);
		// pager.setBackgroundResource(imgIdBackgroundDrawable[appData
		// .getIntData(IDataActions.TYPE_ID)]);
		setBacgroundResource(pager,
				imgIdBackgroundDrawable[appData
						.getIntData(IDataActions.TYPE_ID)]);
		pager.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int arg0) {
				currentPage = arg0;
				page.setText((currentPage + 1) + "/" + totalPage + " "
						+ getString(R.string.page));
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {

			}

			@Override
			public void onPageScrollStateChanged(int arg0) {

			}
		});

		resizeView(pager, 0, 0, 0, 0);

		page = (TextView) findViewById(R.id.help_text);
		resizeView(page, 505, 600, 0, 0);
		page.setTextColor(Color.rgb(102, 51, 0));

		try {
			Typeface font = Typeface.createFromFile(this.getFilesDir()
					.toString() + "/a_otf_jun501pro_bold.otf");
			page.setTypeface(font);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// // TODO:log time
		// if (appData.getStringData(IDataActions.TYPE_NAME).equalsIgnoreCase(
		// "karaoke_clicked")) {
		// logtime.Logstart(Logtime.PAGE_LISTSONG1);
		// logtime.LogPageStart = Logtime.PAGE_LISTSONG1;
		// } else if (appData.getStringData(IDataActions.TYPE_NAME)
		// .equalsIgnoreCase("douga_clicked")) {
		// logtime.Logstart(Logtime.PAGE_LISTSONG2);
		// logtime.LogPageStart = Logtime.PAGE_LISTSONG2;
		// } else if (appData.getStringData(IDataActions.TYPE_NAME)
		// .equalsIgnoreCase("uta_clicked")) {
		// logtime.Logstart(Logtime.PAGE_LISTSONG3);
		// logtime.LogPageStart = Logtime.PAGE_LISTSONG3;
		// }
	}

	@Override
	protected void onStop() {
		// TODO:log time
		// logtime.Logend(Logtime.PAGE_LISTSONG1);
		// logtime.Logend(Logtime.PAGE_LISTSONG2);
		// logtime.Logend(Logtime.PAGE_LISTSONG3);
		super.onStop();

	}

	private DisplayMetrics configMetric() {
		DisplayMetrics metric = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metric);
		metric.widthPixels = Math.round(metric.widthPixels
				* metric.scaledDensity);
		metric.heightPixels = Math.round(metric.heightPixels
				* metric.scaledDensity);

		return metric;
	}

	private OnTouchListener cancelDownload = new OnTouchListener() {

		@Override
		public boolean onTouch(View v, MotionEvent event) {
			try {
				if (imgCancel != null
						&& imgCancel.getVisibility() == View.VISIBLE) {
					if (songFreeDataDownload != null) {
						songFreeDataDownload.cancel(true);
						songFreeDataDownload = null;
					}
					com.xing.joy.processdata.Download.isCancelled = true;
					downloadBar.reset();
					downloadBar.setVisibility(View.GONE);
					imgCancel.setVisibility(View.GONE);
					isTouch = true;
				}
				if (timer != null) {
					timer.cancel();
					timer = null;
				}
			} catch (Exception e) {
			}
			return true;
		}
	};

	private class SongsPagerAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			return totalPage;
		}

		/**
		 * Create the page for the given position. The adapter is responsible
		 * for adding the view to the container given here, although it only
		 * must ensure this is done by the time it returns from
		 * {@link #finishUpdate()}.
		 * 
		 * @param container
		 *            The containing View in which the page will be shown.
		 * @param position
		 *            The page position to be instantiated.
		 * @return Returns an Object representing the new page. This does not
		 *         need to be a View, but can be some other container of the
		 *         page.
		 */
		@Override
		public Object instantiateItem(View collection, int position) {
			RelativeLayout layout = null;
			try {
				layout = createOnPage(position);
				((ViewPager) collection).addView(layout, 0);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return layout;
		}

		/**
		 * Remove a page for the given position. The adapter is responsible for
		 * removing the view from its container, although it only must ensure
		 * this is done by the time it returns from {@link #finishUpdate()}.
		 * 
		 * @param container
		 *            The containing View from which the page will be removed.
		 * @param position
		 *            The page position to be removed.
		 * @param object
		 *            The same object that was returned by
		 *            {@link #instantiateItem(View, int)}.
		 */
		@Override
		public void destroyItem(View collection, int position, Object view) {
			RelativeLayout tmp = (RelativeLayout) view;
			for (int i = 0; i < tmp.getChildCount(); i++) {
				setNullViewDrawable((ImageView) tmp.getChildAt(i));
			}
			tmp.setBackgroundResource(0);
			tmp.removeAllViews();
			tmp.destroyDrawingCache();
			tmp.setBackgroundDrawable(null);
			tmp.setBackgroundResource(0);
			tmp = null;
			((ViewPager) collection).removeView((RelativeLayout) view);
		}

		@Override
		public boolean isViewFromObject(View view, Object object) {
			return view == ((RelativeLayout) object);
		}

		/**
		 * Called when the a change in the shown pages has been completed. At
		 * this point you must ensure that all of the pages have actually been
		 * added or removed from the container as appropriate.
		 * 
		 * @param container
		 *            The containing View which is displaying this adapter's
		 *            page views.
		 */
		@Override
		public void finishUpdate(View arg0) {
		}

		@Override
		public void restoreState(Parcelable arg0, ClassLoader arg1) {
		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View arg0) {
		}

	}

	private ImageView createImageSong(final Songs song) {
		ImageView iw = new ImageView(this);
		ZPath zPath = new ZPath(memory, song, appData);

		boolean isVideo = appData.getIntData(IDataActions.TYPE_ID) == 1;
		iw.setImageDrawable(zPath.getDrawable(isVideo));

		switch (appData.getIntData(IDataActions.TYPE_ID)) {
		case 0:
		case 2:
			// case for karaoke & uta
			resizeViewInView(iw, 200, 166, -400, -200, 0, 0);
			break;
		case 1:
			// video
			resizeViewInView(iw, 317, 166, -400, -200, 0, 0);
			break;
		}

		iw.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (!isTouch) {
					return;
				}

				ZPath zPath = new ZPath(memory, song, appData);
				if (!zPath.checkSongIsDownloaded()) {
					// DOWNLOAD
					FilesModel[] fm = new FilesModel[1];
//					String pathFile = getString(R.string.url_song_free_download);
					String pathFile = urlUtils.getUrl(R.string.url_song_free_download);

					if (isTablet()) {
//						pathFile = getString(R.string.url_song_free_hd_download);
						pathFile = urlUtils.getUrl(R.string.url_song_free_hd_download);
					}

					fm[0] = new FilesModel("song.zip", pathFile
							+ song.getSongNameEnglish().toLowerCase() + ".zip",
							memory.getPathCacheExternalMemory());
					nameSong = song.getSongNameEnglish().toLowerCase();

					if (songFreeDataDownload == null) {
						songFreeDataDownload = (SongFreeDataDownload) new SongFreeDataDownload(
								SelectSongActivity.this).execute(fm);
					}
				} else {
					startActivity(song);
				}
			}

		});
		return iw;
	}

	private String nameSong = "";

	private void startActivity(final Songs song) {

		appData.setStringData(IDataActions.PACKAGE_NAME, song.getPackageName());

		appData.setStringData(IDataActions.SONG_NAME, song.getSongNameEnglish());

		appData.setStringData(IDataActions.SONG_NAME_JAPAN,
				song.getSongNameJapanese());
		appData.setStringData(IDataActions.CLASS_NAME, "com.xing.joy.karaokes."
				+ song.getSongNameEnglish());

		if (appData.getIntData(IDataActions.TYPE_ID) == 1) {
			Zlog.e(SelectSongActivity.class.getName(), "PlayMovieDynamicGame");
			CommonUtils.startNewActivity(SelectSongActivity.this,
					PlayMovieDynamicGameActivity.class, "");
		} else {
			CommonUtils.startNewActivity(SelectSongActivity.this,
					DynamicSongActivity.class, "");
		}
	}

	private RelativeLayout createOnPage(int position) throws Exception {
		RelativeLayout onPage = new RelativeLayout(this);
		// onPage.setBackgroundResource(imgIdBackgroundDrawable[appData
		// .getIntData(IDataActions.TYPE_ID)]);
		setBacgroundResource(onPage,
				imgIdBackgroundDrawable[appData
						.getIntData(IDataActions.TYPE_ID)]);

		resizeViewInView(onPage, 960, 640, 0, 0, 0, 0);
		lpageSong.add(onPage);
		int countSong = iconsOnPage * position;

		for (int j = 0; j < iconsOnPage; j++) {
			ImageView tmp = createImageSong(lsong.get(countSong));
			onPage.addView(tmp);

			int type = appData.getIntData(IDataActions.TYPE_ID);
			if (type == 1) {
				setNewLayout(tmp, coorMovie[j][0], coorMovie[j][1], 0, 0);
			} else if (type == 0 || type == 2) {
				setNewLayout(tmp, coorSong[j][0], coorSong[j][1], 0, 0);
			}

			countSong++;
			if (countSong >= lsong.size()) {
				break;
			}
		}

		return onPage;
	}

	private class GetPackageInfo extends AsyncTask<Void, Integer, Long> {
		protected Long doInBackground(Void... params) {
			try {
				listPackagesAndAddFreeSong();
			} catch (Exception e) {
				Zlog.e(SelectSongActivity.class.getName(), e);
			}

			Zparse zparse = new Zparse();
			packageSongs = zparse.parsePackageInfoXMLOfSelectSong(memory);

			for (int i = 0; i < arrListPackages.size(); i++) {
				getInforOfEachPackage(arrListPackages.get(i));
			}

			return (long) 0;
		}

		protected void onProgressUpdate(Integer... progress) {
		}

		protected void onPostExecute(Long result) {

			layoutPagesView();

			if (imgBack == null) {
				Runnable runnable = new Runnable() {
					@Override
					public void run() {
						addBackButton(R.id.select_display);
						isTouch = true;
					}
				};

				new Handler().postDelayed(runnable, 1000);
			}
		}

		public void getInforOfEachPackage(String pack) {
			try {
				// check relation songs
				if (pack.contains("free.song.relation")) {
					if (!packageSongs.containsKey(pack)) {
						return;
					}
				}
				// TODO:fix return
				// check songs bought
				if (!Boolean.parseBoolean(prefs.getString(pack,
						isDebug() + ";0").split(";")[0])) {
					// Zlog.e(SelectSong.class.getName(), "DEBUG FAIL");
					// return;
				}

				String path = memory.getPathFileExternalMemory() + pack
						+ ".ini";

				File txt = new File(path);
				BufferedReader br = new BufferedReader(new FileReader(txt));
				String line;
				while ((line = br.readLine()) != null) {
					String[] info = line.trim().split("#");
					Boolean checkSong = false;
					// new song
					if (info[4].trim().equalsIgnoreCase("NULL")
							&& appData.getStringData(IDataActions.TYPE_NAME)
									.equalsIgnoreCase("douga_clicked")) {
						continue;
					}
					if (lsong != null) {
						for (Iterator<Songs> iterator = lsong.iterator(); iterator
								.hasNext();) {
							Songs song = (Songs) iterator.next();
							if (song.getSongNameEnglish().equalsIgnoreCase(
									info[1].trim())) {
								checkSong = true;
							}
						}
					}

					if (!checkSong) {
						int id = 1;
						info[0] = "1";
						try {
							id = Integer.parseInt(info[0].trim());
						} catch (Exception ex) {

						}
						long datePurchase = Long.parseLong(prefs.getString(
								pack, isDebug() + ";0").split(";")[1]);
						Songs tmp = new Songs(info[1].trim(), info[2].trim(),
								id, pack, datePurchase, info[3].trim(),
								info[4].trim());

						lsong.add(tmp);
					}
				}
				br.close();
			} catch (Exception e) {
				Zlog.e(SelectSongActivity.class.getName() + ":----------------",
						e);
			}
		}
	}

	private void layoutPagesView() {

		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				// if (isPurchased(tmp.getPackageName())) {
				//
				// }
				if (lsong != null) {

					List<Songs> list = new ArrayList<Songs>();
					list.addAll(lsong);
					lsong.clear();

					for (Songs songs : list) {
						if (isPurchased(songs.getPackageName())
								|| songs.getPackageName().equals("")
								|| isDebug()) {
							lsong.add(songs);
						}
					}
				}

				if (lsong != null) {

					totalPage = lsong.size() / iconsOnPage;
					if (lsong.size() % iconsOnPage > 0) {
						totalPage += 1;
					}
					if (totalPage == 0) {
						totalPage = 1;
					}
				}

				if (currentPage >= totalPage) {
					currentPage = totalPage - 1;
				}

				if (lsong != null && lsong.size() > 0) {
					changeSortDisplay(currentPage);
				}
			}
		};
		handler.postDelayed(runnable, 50);
	}

	private void sortOrderSong(int type) throws Exception {
		// sort name
		if (type == 0) {
			Collections.sort(lsong, Songs.SongNameComparator);
		} else if (type == 1 || type == 2) {
			// sort date
			Songs.sortASC = (type == 1);
			Collections.sort(lsong);
		}
	}

	private class SongFreeDataDownload extends Download {

		@Override
		protected void onPreExecute() {
			isTouch = false;
			if (downloadBar == null) {
				downloadBar = (DownloadProgessBar) findViewById(R.id.download_bar);
				DownloadProgessBar.typeDataDownload = 0;
				resizeView(downloadBar, 163, 396, 0, 0);
			}

			downloadBar.setVisibility(View.VISIBLE);
			timer = new Timer();
			timer.scheduleAtFixedRate(new TimerTask() {

				@Override
				public void run() {
					if (DownloadProgessBar.MAX > 0) {
						runOnUiThread(new Runnable() {

							@Override
							public void run() {
								imgCancel.setVisibility(View.VISIBLE);
								if (timer != null)
									timer.cancel();
								timer = null;
							}
						});
					}
				}
			}, 0, 300);

			super.onPreExecute();
		}

		@Override
		public void onProgressUpdate(Integer... args) {
			if (args[0] != null) {
				downloadBar.updateProgessBar(args[0]);
			}
		}

		public SongFreeDataDownload(Context context) {
			super(context, true);
		}

		@Override
		protected void onPostExecute(Boolean result) {
			try {
				if (timer != null) {
					timer.cancel();
					timer = null;
				}
			} catch (Exception e) {
			}
			if (result != null && result) {
				// unzip
				try {
					FilesModel[] fm = new FilesModel[1];
					fm[0] = new FilesModel("song.zip",
							memory.getPathCacheExternalMemory() + "song.zip",
							memory.getPathFileInternalMemory());
					DownloadProgessBar.STATUS_DOWNLOAD = getString(R.string.dlp_unzip);
					downloadBar.invalidate();
					new SongFreeDataUnzip().execute(fm);
					songFreeDataDownload = null;
				} catch (Exception e) {
				}
			} else {
				try {
					downloadBar.setVisibility(View.GONE);
					imgCancel.setVisibility(View.GONE);
					downloadBar.reset();
					songFreeDataDownload = null;
					isTouch = true;
				} catch (Exception e) {
				}
			}
		}
	}

	private class SongFreeDataUnzip extends Unzip {

		@Override
		protected void onPreExecute() {
			try {
				imgCancel.setVisibility(View.GONE);
			} catch (Exception e) {
			}
		}

		@Override
		protected void onPostExecute(Boolean result) {
			isTouch = true;
			if (result != null && result) {
				changeSortDisplay(currentPage);
				if (downloadBar != null) {
					downloadBar.setVisibility(View.GONE);
					downloadBar.reset();
				}
				isTouch = true;
			} else {
				ZUnzip zUnzip = new ZUnzip(SelectSongActivity.this);
				zUnzip.deleteSelectSongFree(memory, nameSong);

				changeSortDisplay(currentPage);
				if (downloadBar != null) {
					downloadBar.setVisibility(View.GONE);
					downloadBar.reset();
				}

				isTouch = true;

			}
		}
	}

	private void listPackagesAndAddFreeSong() throws NumberFormatException,
			IOException, Exception {
		// Get free song
		String path = memory.getPathFileInternalMemory() + "free.song.ini";
		File txt = new File(path);
		BufferedReader br = new BufferedReader(new FileReader(txt));
		String line;
		while ((line = br.readLine()) != null) {
			String[] info = line.split("#");
			if (info[4].equalsIgnoreCase("NULL")
					&& appData.getStringData(IDataActions.TYPE_NAME)
							.equalsIgnoreCase("douga_clicked")) {
				continue;
			}

			Songs tmp = new Songs(info[1], info[2], Integer.parseInt(info[0]),
					"", 1000000000000l, info[3], info[4]);
			lsong.add(tmp);
		}

		br.close();

		// Get package bought
		File dir = new File(memory.getPathFileExternalMemory());
		File[] filelist = dir.listFiles();
		if (filelist != null) {
			for (int i = 0; i < filelist.length; i++) {

				if (filelist[i].isFile()
						&& filelist[i].getName().endsWith(".ini")) {
					arrListPackages.add(filelist[i].getName().substring(0,
							filelist[i].getName().length() - 4));
				}
			}
		}
	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
		try {
			if (hasFocus) {
				if (draBuyBt != null) {
					draBuyBt.start();
				}
			}
		} catch (Exception e) {
		}

		if (page != null) {
			page.setTextSize(TypedValue.COMPLEX_UNIT_PX,
					new Zparse().parsePage(page.getHeight() / 2));
		}
	}

	@Override
	public void onBackPressed() {
		// if (imgBack != null && isTouch) {
		releaseMemory();
		CommonUtils.startNewActivity(this, TopActivity.class, "");
		// }
		super.onBackPressed();
	}

	@Override
	protected void onUserLeaveHint() {
		super.onUserLeaveHint();
	}

	@Override
	protected void onPause() {
		if (alertDialog != null && alertDialog.isShowing()) {
			alertDialog.dismiss();
			alertDialog = null;
		}
		System.gc();
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		if (songFreeDataDownload != null) {
			songFreeDataDownload.cancel(true);
			songFreeDataDownload = null;
		}
		super.onDestroy();
	}

	@Override
	public void releaseMemory() {
		super.releaseMemory();
		if (page != null) {
			page.setText("");
			page = null;
		}

		if (imgSlide != null) {
			setNullViewDrawable(imgSlide);
			imgSlide = null;
		}

		if (arrListPackages != null) {
			arrListPackages.clear();
			arrListPackages = null;
		}

		if (lsong != null) {
			lsong.clear();
			lsong = null;
		}

		if (draBuyBt != null) {
			draBuyBt.stop();
			draBuyBt = null;
		}

		if (lpageSong != null) {
			for (Iterator<RelativeLayout> getPage = lpageSong.iterator(); getPage
					.hasNext();) {
				RelativeLayout page = (RelativeLayout) getPage.next();
				for (int i = 0; i < page.getChildCount(); i++) {
					setNullViewDrawable((ImageView) page.getChildAt(i));
				}
				page.clearDisappearingChildren();
				page.removeAllViews();
				page.removeAllViewsInLayout();
				page.setBackgroundResource(0);
				page.removeAllViews();
				page.destroyDrawingCache();
				page.setBackgroundDrawable(null);
				page.setBackgroundResource(0);
				page = null;
			}

			lpageSong.clear();
		}

		setNullViewDrawable(imgSortName);
		imgSortName = null;
		setNullViewDrawable(imgSortOld);
		imgSortOld = null;
		setNullViewDrawable(imgSortNew);
		imgSortNew = null;
		setNullViewDrawable(imgBuyBt);
		imgBuyBt = null;
		songsAdapter = null;
		pager = null;

	}

	/**
	 * Show image for image
	 * */
	private void setImageSort(int sort) {
		int[] sname = new int[] { R.drawable.aiueo_on_iphone,
				R.drawable.aiueo_off_iphone };
		int[] snew = new int[] { R.drawable.new_on_iphone,
				R.drawable.new_off_iphone };
		int[] sold = new int[] { R.drawable.old_on_iphone,
				R.drawable.old_off_iphone };

		// imgSortName.setBackgroundResource(sname[sort == 0 ? 0 : 1]);
		setBacgroundResource(imgSortName, sname[sort == 0 ? 0 : 1]);

		// imgSortNew.setBackgroundResource(snew[sort == 2 ? 0 : 1]);

		setBacgroundResource(imgSortNew, snew[sort == 2 ? 0 : 1]);
		// imgSortOld.setBackgroundResource(sold[sort == 1 ? 0 : 1]);
		setBacgroundResource(imgSortOld, sold[sort == 1 ? 0 : 1]);
	}

	private void changeSortDisplay(int currentPage) {
		try {
			page.setText((currentPage + 1) + "/" + totalPage + " "
					+ getString(R.string.page));
			if (lpageSong != null) {
				for (Iterator<RelativeLayout> getPage = lpageSong.iterator(); getPage
						.hasNext();) {
					RelativeLayout page = (RelativeLayout) getPage.next();
					for (int i = 0; i < page.getChildCount(); i++) {
						setNullViewDrawable((ImageView) page.getChildAt(i));
					}

					page.clearDisappearingChildren();
					page.removeAllViews();
					page.removeAllViewsInLayout();
				}

				lpageSong.clear();
			}
			sortOrderSong(currentTypeSort);
			setImageSort(currentTypeSort);
			songsAdapter = null;
			songsAdapter = new SongsPagerAdapter();
			pager.setAdapter(songsAdapter);
			pager.setCurrentItem(currentPage, false);
			pager.setBackgroundResource(0);
		} catch (Exception e) {
		}
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN && isTouch) {

			if (R.id.buy_bt == v.getId()) {
				releaseMemory();
				CommonUtils.startNewActivity(this, BuyActivity.class,
						"SelectSong");
				return true;
			}

			int id = v.getId();

			currentTypeSort = (id == R.id.sort_name) ? 0
					: ((R.id.sort_old == id) ? 1 : 2);

			currentPage = 0;
			changeSortDisplay(currentPage);
		}
		return true;
	}

	@Override
	protected void onIabPurchaseFinish(boolean failure, String sku) {
		// TODO Auto-generated method stub

	}

	@Override
	public String getNameCount() {

		// TODO:log time
		if (appData.getStringData(IDataActions.TYPE_NAME).equalsIgnoreCase(
				"karaoke_clicked")) {
			// return Logtime.PAGE_LISTSONG1;
			return getResources()
					.getString(R.string.namescreen_selectsong_tab1);
		} else if (appData.getStringData(IDataActions.TYPE_NAME)
				.equalsIgnoreCase("douga_clicked")) {
			// return Logtime.PAGE_LISTSONG2;
			return getResources()
					.getString(R.string.namescreen_selectsong_tab2);
		} else if (appData.getStringData(IDataActions.TYPE_NAME)
				.equalsIgnoreCase("uta_clicked")) {
			// return Logtime.PAGE_LISTSONG3;
			return getResources()
					.getString(R.string.namescreen_selectsong_tab3);
		}

		// return Logtime.PAGE_LISTSONG1;
		return getResources().getString(R.string.namescreen_selectsong_tab1);
	}
}