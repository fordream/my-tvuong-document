package com.xing.joy.others.zzz;

import android.view.View;
import android.view.animation.AlphaAnimation;

public class ZAnimation {
	public void setAlpha(final View view, float start, float end, long time) {
		final AlphaAnimation alphaAnimation = new AlphaAnimation(start, end);
		alphaAnimation.setDuration(time);
		alphaAnimation.setFillAfter(true);
		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				view.startAnimation(alphaAnimation);
			}
		};
		if (view != null)
			view.post(runnable);
	}
}