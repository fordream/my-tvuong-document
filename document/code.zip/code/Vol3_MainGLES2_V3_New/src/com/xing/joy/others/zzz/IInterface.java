package com.xing.joy.others.zzz;

public interface IInterface {
	public static final int SIZE_6 = 6;
}