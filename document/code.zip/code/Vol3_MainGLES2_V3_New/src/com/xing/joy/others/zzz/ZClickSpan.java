package com.xing.joy.others.zzz;

import android.text.SpannableString;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.TextView;

public class ZClickSpan {

	public interface OnClickListener {
		void onClick();
	}

	public void addLink(TextView popUp_textView2, String text,
			View.OnClickListener onClickListener) {
		SpannableString link = makeLinkSpan(text, onClickListener);
		popUp_textView2.append(link);
	}

	private SpannableString makeLinkSpan(CharSequence text,
			View.OnClickListener listener) {
		SpannableString link = new SpannableString(text);
		link.setSpan(new ClickableString(listener), 0, text.length(),
				SpannableString.SPAN_INCLUSIVE_EXCLUSIVE);
		return link;
	}

	private class ClickableString extends ClickableSpan {
		private View.OnClickListener mListener;

		public ClickableString(View.OnClickListener listener) {
			mListener = listener;
		}

		@Override
		public void onClick(View v) {
			mListener.onClick(v);
		}
	}
}