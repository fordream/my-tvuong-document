package com.xing.joy.others.zzz;

import java.io.File;

import jp.co.xing.utaehon03.util.MemoryUtils;
import android.content.Context;

public class ZUnzip {
	private Context context;

	public ZUnzip(Context context) {
		this.context = context;
	}

	public void deleteItemBuy(MemoryUtils memoryUtils, String idBuy) {
		String path = memoryUtils.getPathFileExternalMemory()
				+ File.separatorChar + idBuy + ".ini";
		File file = new File(path);
		// Builder builder = new Builder(context);
		// builder.setMessage(file.exists() + "\n"+ path);
		// builder.show();
		file.delete();
	}

	public void deleteSelectSongFree(MemoryUtils memoryUtils, String nameSong) {
		String path = memoryUtils.getPathFileInternalMemory() + nameSong;
		File file = new File(path);
		// Builder builder = new Builder(context);
		// builder.setMessage(file.exists() + "\n" + path);
		// builder.show();

		// file.delete();
		deleteDirectory(file);
	}

	private boolean deleteDirectory(File path) {
		if (path.exists()) {
			File[] files = path.listFiles();
			if (files == null) {
				return true;
			}
			for (int i = 0; i < files.length; i++) {
				if (files[i].isDirectory()) {
					deleteDirectory(files[i]);
				} else {
					files[i].delete();
				}
			}
		}

		return (path.delete());
	}

	public void deleteTop(MemoryUtils memory) {
		String path = memory.getPathFileInternalMemory();
		File file = new File(path);
		deleteDirectory(file);
	}

	public byte[] data(int file_size) throws Exception {

		if (file_size >= 8 * 1024) {
			return new byte[8 * 1024];
		} else {
			return new byte[file_size];
		}
		// if (file_size <= 1024 * 2) {
		// return new byte[file_size];
		// } else {
		// return new byte[8 * 1024];
		//
		// try {
		// return new byte[file_size];
		// } catch (OutOfMemoryError exception) {
		// return data(file_size / 2);
		// }
		// }
	}
}
