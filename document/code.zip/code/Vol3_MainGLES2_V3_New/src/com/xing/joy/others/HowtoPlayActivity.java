package com.xing.joy.others;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

import jp.co.xing.utaehon03.util.CommonUtils;
import jp.naver.KDTCUE.R;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.TextView;

import com.xing.joy.common.CoreActivity;
import com.xing.joy.others.zzz.ZPath;

/**
 * 
 * 
 */
public class HowtoPlayActivity extends CoreActivity implements OnTouchListener {

	/** Image back, background, help, left, right button. */
	private ImageView background, imgHelp, btLeft, btRight;

	/** Media player. */
	private MediaPlayer mediaplayer;
	private TextView tvPage;

	/** Index of image. */
	private int count = 1;

	private ArrayList<String> strImgHelp = new ArrayList<String>();

	/**
	 * Create views
	 */
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.howto_play);

		createHemImage(R.id.howto_play_display);
		addBackButton(R.id.howto_play_display);

		background = (ImageView) findViewById(R.id.help_background);
		resizeView(background, 0, 0, 0, 0);

		imgHelp = (ImageView) findViewById(R.id.help_image);
		resizeView(imgHelp, 0, 0, 0, 0);

		btLeft = (ImageView) findViewById(R.id.help_left);
		resizeView(btLeft, 10, 555, 0, 0);

		btRight = (ImageView) findViewById(R.id.help_right);
		resizeView(btRight, 872, 555, 0, 0);

		tvPage = (TextView) findViewById(R.id.help_text);
		resizeView(tvPage, 450, 565, 0, 0);

		// Set font for textview
		Typeface font = Typeface.createFromFile(this.getFilesDir().toString()
				+ "/a_otf_jun501pro_bold.otf");
		tvPage.setTypeface(font);

		// get data
		parseHelpFile(new File(memory.getPathFileInternalMemory()
				+ "img_helper/", "help.txt"));

		// TODO:log time
		// logtime.Logstart(Logtime.PAGE_HELP);
		// logtime.LogPageStart = Logtime.PAGE_HELP;
	}

	@Override
	protected void onStop() {
		super.onStop();
		// TODO:log time
		// logtime.Logend(Logtime.PAGE_HELP);
	}

	private void parseHelpFile(File file) {
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line;
			while (!(line = br.readLine()).equalsIgnoreCase("")) {
				String[] tmp = line.split("#");
				strImgHelp.add(tmp[1]);
				tmp = null;
			}

			br.close();
		} catch (Exception e) {
		}
	}

	@Override
	public void onResume() {
		super.onResume();
		if (mediaplayer == null) {
			mediaplayer = MediaPlayer.create(this, R.raw.opening);
			mediaplayer.setVolume(volume, volume);
			mediaplayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
			mediaplayer.setLooping(true);
		}
		mediaplayer.start();
	}

	@Override
	public void onPause() {
		super.onPause();
		if (mediaplayer != null) {
			mediaplayer.stop();
			mediaplayer.release();
			mediaplayer = null;
		}
	}

	@Override
	public void onWindowFocusChanged(boolean pHasWindowFocus) {
		super.onWindowFocusChanged(pHasWindowFocus);
		if (pHasWindowFocus) {
			setBackground();
		}
	}

	/**
	 * Action for touch
	 */
	@Override
	public boolean onTouch(View view, MotionEvent event) {

		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			switch (view.getId()) {
			case R.id.help_left:
				if (count > 1) {
					count--;
					setBackground();
				}

				break;
			case R.id.help_right:
				if (count < strImgHelp.size()) {
					count++;
					setBackground();
				}

				break;
			}
		}
		return true;
	}

	/**
	 * set background .
	 */
	private void setBackground() {

		if (btLeft == null || btRight == null || imgHelp == null) {
			return;
		}

		btLeft.setOnTouchListener(this);
		btRight.setOnTouchListener(this);

		int leftVisibility = (count == 1 ? View.INVISIBLE : View.VISIBLE);
		btLeft.setVisibility(leftVisibility);

		int rightVisibility = (count == strImgHelp.size() ? View.INVISIBLE
				: View.VISIBLE);
		btRight.setVisibility(rightVisibility);

		Drawable d = new ZPath(memory).getDrawableHelp(strImgHelp
				.get(count - 1));
		imgHelp.setBackgroundDrawable(d);

		return;
	}

	@Override
	public void releaseMemory() {
		if (strImgHelp != null) {
			strImgHelp.clear();
			strImgHelp = null;
		}
		if (mediaplayer != null) {
			mediaplayer.stop();
			mediaplayer.release();
			mediaplayer = null;
		}
		if (tvPage != null) {
			tvPage.setText("");
		}

		setNullViewDrawable(imgHelp);
		setNullViewDrawable(btLeft);
		setNullViewDrawable(btRight);
		setNullViewDrawable(background);

		tvPage = null;
		imgHelp = null;
		btLeft = null;
		btRight = null;
		background = null;
		System.gc();
		super.releaseMemory();
	}

	@Override
	protected void onDestroy() {

		if (mediaplayer != null) {
			mediaplayer.stop();
			mediaplayer.release();
			mediaplayer = null;
		}
		setNullViewDrawable(imgHelp);
		setNullViewDrawable(btLeft);
		setNullViewDrawable(btRight);

		imgHelp = null;
		btLeft = null;
		btRight = null;
		System.gc();
		super.onDestroy();
	}

	@Override
	public void onBackPressed() {
		releaseMemory();
		CommonUtils.startNewActivity(this, TopActivity.class, "");
		super.onBackPressed();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {
		case KeyEvent.KEYCODE_VOLUME_UP:
			audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC,
					AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
			float streamVolumeCurrent = audioManager
					.getStreamVolume(AudioManager.STREAM_MUSIC);
			float streamVolumeMax = audioManager
					.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
			volume = streamVolumeCurrent / streamVolumeMax;
			mediaplayer.setVolume(volume, volume);
			return true;
		case KeyEvent.KEYCODE_VOLUME_DOWN:
			audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC,
					AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
			streamVolumeCurrent = audioManager
					.getStreamVolume(AudioManager.STREAM_MUSIC);
			streamVolumeMax = audioManager
					.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
			volume = streamVolumeCurrent / streamVolumeMax;
			mediaplayer.setVolume(volume, volume);
			return true;
		default:
			return super.onKeyDown(keyCode, event);
		}
	}

	@Override
	public String getNameCount() {
		// TODO Auto-generated method stub
		// return Logtime.PAGE_HELP;

		return getResources().getString(R.string.namescreen_help);
	}
}
