package com.xing.joy.others.zzz;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import jp.co.xing.utaehon03.util.MemoryUtils;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import com.xing.joy.common.PackageSongs;
import com.xing.joy.common.PackageXMLHandler;
import com.xing.joy.common.PackagesList;

public class Zparse {

	public Zparse() {
		// TODO Auto-generated constructor stub
	}

	public List<PackageSongs> parsePackageInfoXML(MemoryUtils memory) {
		List<PackageSongs> packageSongs = new ArrayList<PackageSongs>();
		try {
			if (new File(memory.getPathFileInternalMemory() + "img_buy/"
					+ "package_info.xml").exists()) {
				SAXParserFactory spf = SAXParserFactory.newInstance();
				SAXParser sp = spf.newSAXParser();
				XMLReader xr = sp.getXMLReader();

				PackageXMLHandler packageXMLHandler = new PackageXMLHandler();
				xr.setContentHandler(packageXMLHandler);
				File packageInfo = new File(memory.getPathFileInternalMemory()
						+ "img_buy/" + "package_info.xml");
				InputStream inputStream = new FileInputStream(packageInfo);
				Reader reader = new InputStreamReader(inputStream, "UTF-8");
				xr.parse(new InputSource(reader));

				PackagesList packagesList = PackageXMLHandler.pList;
				if (packagesList != null) {
					PackageSongs.resetCountPackages();
					for (int i = 0; i < packagesList.getName().size(); i++) {
						PackageSongs _packageSongs = new PackageSongs(
								packagesList.getId().get(i), packagesList
										.getSongNumber().get(i), packagesList
										.getName().get(i), packagesList
										.getChecksum().get(i), packagesList
										.getIcon().get(i), packagesList
										.getImageIntro().get(i), packagesList
										.getVol().get(i), packagesList
										.getPackageRelation().get(i));
						_packageSongs.setPackageVol(3);

						packageSongs.add(_packageSongs);
					}
				}

			}
		} catch (Exception exception) {
		}

		return packageSongs;
	}

	public HashMap<String, Boolean> parsePackageInfoXMLOfSelectSong(
			MemoryUtils memory) {
		HashMap<String, Boolean> packageSongs = new HashMap<String, Boolean>();

		String path = "img_buy/package_info.xml";
		/** Handling & parser XML . */
		if (new File(memory.getPathFileInternalMemory() + path).exists()) {
			try {
				/** Handling XML . */
				SAXParserFactory spf = SAXParserFactory.newInstance();
				SAXParser sp = spf.newSAXParser();
				XMLReader xr = sp.getXMLReader();

				/** Create handler to handle XML Tags ( extends DefaultHandler ) */
				PackageXMLHandler packageXMLHandler = new PackageXMLHandler();
				xr.setContentHandler(packageXMLHandler);
				File packageInfo = new File(memory.getPathFileInternalMemory()
						+ path);
				InputStream inputStream = new FileInputStream(packageInfo);
				Reader reader = new InputStreamReader(inputStream, "UTF-8");
				xr.parse(new InputSource(reader));

				// get package list after parse XML.
				PackagesList packagesList = PackageXMLHandler.pList;

				if (packagesList != null) {
					PackageSongs.resetCountPackages();
					for (int i = 0; i < packagesList.getName().size(); i++) {
						packageSongs.put(packagesList.getName().get(i), true);
					}
				}
			} catch (Exception e) {
			}
		}
		return packageSongs;
	}

	public int parsePage(int sizePage) {
		if (sizePage < 20) {
			return 20;
		}
		if (sizePage > 40) {
			return 40;
		}

		return sizePage;
	}

}