package com.xing.joy.processdata;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.PasswordAuthentication;
import java.net.URL;

import jp.co.xing.utaehon03.util.MemoryUtils;
import jp.naver.KDTCUE.R;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.xing.joy.common.DownloadProgessBar;
import com.xing.joy.download.DigestUtils;

@SuppressLint("HandlerLeak")
public class Download extends AsyncTask<FilesModel, Integer, Boolean> {

	/** Share preferences store data. */
	protected SharedPreferences shareHistoryDownload;

	/** Editor access share data. */
	private Editor editHistoryDownload;

	protected long total = 0, fileSize = 0;

	private Context context;

	/** BUFFER read file. */
	// private static final int BUFFER = 2048;
	private static final int BUFFER = 1024 * 2;

	private Handler messageHandler;

	private boolean checkSD = false;

	private static AlertDialog alertDialog;

	private String message = "";

	private Boolean allowDownload = true;

	public static boolean isCancelled = false;

	public Download(final Context context, boolean checkSD) {
		super();
		this.context = context;
		this.checkSD = checkSD;
		Authenticator.setDefault(new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(context
						.getString(R.string.url_user), context.getString(
						R.string.url_password).toCharArray());
			}
		});
		shareHistoryDownload = context.getSharedPreferences("history_download",
				Context.MODE_PRIVATE);
		editHistoryDownload = shareHistoryDownload.edit();
	}

	public void popupDownload(String message) throws Exception {
		alertDialog = new AlertDialog.Builder(context).create();
		alertDialog.setMessage(message);
		alertDialog.setButton(context.getString(R.string.btn_yes),
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						alertDialog.dismiss();
						return;
					}
				});
		alertDialog.show();
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		Download.isCancelled = false;
		new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					long tmp = 0;
					long time = 0;
					int count = 0;
					while (true) {

						Thread.sleep(1000);
						if (total >= DownloadProgessBar.MAX
								|| DownloadProgessBar.MAX == 0
								|| Download.isCancelled) {
							break;
						}
						time++;
						if (time > 5 && (total - tmp) / 1024 < 1) {
							count++;
							if (count >= 5) {
								allowDownload = false;
								break;
							}
						}
						tmp = total;
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}
		}).start();
		messageHandler = new Handler() {

			@Override
			public void handleMessage(Message msg) {
				if (Download.isCancelled) {
					return;
				}
				switch (msg.what) {
				case 0:
					try {
						popupDownload(context
								.getString(R.string.dlp_sdc_not_avai));
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				case 1:
					try {
						popupDownload(context
								.getString(R.string.dlp_sdc_not_enuf));
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				case 2:
					try {
						popupDownload(context
								.getString(R.string.download_failed));
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				case 3:
					try {
						popupDownload(message);
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				case 4:
					try {
						popupDownload(context.getString(R.string.server_failed));
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				}
			}

		};
	}

	@Override
	protected void onCancelled() {
		super.onPreExecute();
	}

	@Override
	protected void onPostExecute(Boolean result) {
		super.onPreExecute();
	}

	@SuppressLint("HandlerLeak")
	@Override
	protected Boolean doInBackground(FilesModel... params) {
		// create directory
		Download.isCancelled = false;
		File mDirectory = new File(params[0].getPathDir());
		if (!mDirectory.exists()) {
			mDirectory.mkdirs();
		}
		int messageId = -1;
		for (FilesModel filesModel : params) {
			// create file
			File mFile = new File(filesModel.getPathDir(),
					filesModel.getFileName());

			URL tmp = null;
			System.setProperty("http.keepAlive", "false");
			HttpURLConnection urlConnection = null;
			FileOutputStream fileOutput = null;
			long fileSize = 0;
			String getDateModifier = null;
			try {
				tmp = new URL(filesModel.getUrl());
				urlConnection = (HttpURLConnection) tmp.openConnection();
				// set up some things on the connection.
				urlConnection.setDoInput(true);
				urlConnection.setRequestMethod("GET");
				urlConnection.setReadTimeout(45000);
				urlConnection.setConnectTimeout(45000);
				// and connect!
				urlConnection.connect();

				// Check valid download
				String typeData = urlConnection.getHeaderField("content-type");
				if (typeData.contains("text/plain")) {
					BufferedReader in = new BufferedReader(
							new InputStreamReader(
									urlConnection.getInputStream()));
					messageId = 3;
					message = in.readLine();
					throw new Exception();
				}

				fileSize = urlConnection.getContentLength();
				if (checkSD) {
					MemoryUtils sdc = new MemoryUtils(context);
					double SDCFreeMemory = sdc.checkSDFreeMB();
					if (SDCFreeMemory == 0) {
						messageId = 0;
						throw new Exception();
					} else if (SDCFreeMemory < (fileSize * 2 / (1024 * 1024) + 10)) {
						messageId = 1;
						throw new Exception();
					}
				}
				if (params.length == 1) {
					DownloadProgessBar.MAX = fileSize;
					DownloadProgessBar.calculateMaxDownload();
				}
				fileSize = Long.parseLong(urlConnection
						.getHeaderField("content-length"));
				getDateModifier = urlConnection.getHeaderField("last-modified");

				// set the path where we want to save the file
				// this will be used to write the DOWNLOAD data into
				// the file we created.
				fileOutput = new FileOutputStream(mFile);

				// this will be used in reading the data from the INTERNET.
				InputStream inputStream = urlConnection.getInputStream();

				// create a buffer...
				byte[] buffer = new byte[BUFFER];
				int bufferLength = 0; // used to store a temporary size
										// of the buffer

				// now, read through the input buffer and write.
				while (!isCancelled()
						&& (bufferLength = inputStream.read(buffer)) > 0) {
					if (!allowDownload) {
						messageId = 4;
						throw new Exception();
					}
					total += bufferLength;
					// Log.d("DOWNLOAD", "............");
					publishProgress(bufferLength);
					// add the data in the buffer to the file in the
					// file output stream (the file on the SDCard)
					fileOutput.write(buffer, 0, bufferLength);
				}

				// check checksum
				if (filesModel.getChecksum() != null
						&& !filesModel.getChecksum().equalsIgnoreCase("")) {
					InputStream input = new FileInputStream(mFile);
					String md5Font = DigestUtils.md5Hex(input);
					if (!md5Font.equalsIgnoreCase(filesModel.getChecksum()
							.trim())) {
						// checksum error!
						throw new Exception();
					}
				}
				fileOutput.close();
			} catch (Exception e) {
				if (messageId == -1) {
					messageId = 2;
				}
				e.printStackTrace();
			} finally {
				// close the output stream when done.
				try {
					urlConnection.disconnect();
					if (mFile.length() < fileSize) {
						mFile.delete();
					} else {
						editHistoryDownload.putString(filesModel.getFileName(),
								getDateModifier);
						editHistoryDownload.commit();
					}
					if (messageId != -1) {
						Log.d("TEST", "Message " + messageId);
						messageHandler.sendEmptyMessage(messageId);
						return false;
					}
				} catch (Exception e2) {
					e2.printStackTrace();
					return false;
				}
			}
		}
		return !isCancelled();
	}

}
