package com.xing.joy.others.zzz;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import jp.co.xing.utaehon03.util.MemoryUtils;
import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

import com.xing.joy.common.Songs;
import com.xing.joy.others.SelectSongActivity;
import com.xing.joy.processdata.ApplicationData;

public class ZPath {
	private MemoryUtils memory;
	private Songs song;
	private ApplicationData appData;

	public ZPath(MemoryUtils memory, Songs pathImage, ApplicationData appData) {
		super();
		this.memory = memory;
		this.song = pathImage;
		this.appData = appData;
	}

	public ZPath(MemoryUtils memory) {
		super();
		this.memory = memory;
	}

	public Bitmap getBitmap(boolean isPathMovie) {
		String path1;

		String path = song.getPathImage();

		if (isPathMovie) {
			path = song.getPathImageMovie();
		}
		if (!"".equals(song.getPackageName())) {
			Zlog.e(SelectSongActivity.class.getName(), "0");
			path1 = memory.getPathFileExternalMemory() + path + ".nomedia";
		} else {
			if (!checkSongIsDownloaded()) {
				path1 = memory.getPathFileInternalMemory() + path
						+ "_before.png.nomedia";
			} else {
				path1 = memory.getPathFileInternalMemory() + path
						+ ".png.nomedia";
			}
		}

		InputStream in1 = null;
		try {
			File tmp = new File(path1);
			in1 = new FileInputStream(tmp);
			in1.read(tmp.getName().replace(".nomedia", "").getBytes());
		} catch (final Exception e) {
			e.printStackTrace();
		}
		Bitmap bmImg = BitmapFactory.decodeStream(in1);
		System.gc();

		return bmImg;
	}

	public Drawable getDrawable(boolean isPathMovie) {
		return new BitmapDrawable(getBitmap(isPathMovie));
	}

	@SuppressLint("DefaultLocale")
	public boolean checkSongIsDownloaded() {
		String songName = song.getSongNameEnglish();
		String songPackage = song.getPackageName();
		if (songPackage.equalsIgnoreCase("")) {
			return new File(memory.getPathFileInternalMemory()
					+ songName.toLowerCase() + "/" + songName.toLowerCase()
					+ ".jar").exists();
		} else {
			return new File(memory.getPathFileExternalMemory()
					+ songName.toLowerCase() + "/" + songName.toLowerCase()
					+ ".jar").exists();
		}
	}

	public Drawable getDrawableHelp(String pathName) {
		Bitmap bmImg = BitmapFactory.decodeFile(memory
				.getPathFileInternalMemory() + "img_helper/" + pathName);
		return new BitmapDrawable(bmImg);
	}
}