package com.android.gcm.database;

import java.util.Date;

import jp.co.xing.utaehon.v2.UtaehonSplashActivity;
import android.content.Context;
import android.content.SharedPreferences;

import com.xing.joy.others.BuyActivity;
import com.xing.joy.others.CreditActivity;
import com.xing.joy.others.HowtoPlayActivity;
import com.xing.joy.others.SelectSongActivity;
import com.xing.joy.others.TopActivity;
import com.xing.joy.play.DynamicSongActivity;
import com.xing.joy.play.PlayMovieDynamicGameActivity;

public class DBStore {
	private Context context;
	private SharedPreferences sharedPreferences;
	@SuppressWarnings("unused")
	private String nameScreen[] = new String[] {
			UtaehonSplashActivity.class.getName(),
			DynamicSongActivity.class.getName(),
			PlayMovieDynamicGameActivity.class.getName(),
			BuyActivity.class.getName(), CreditActivity.class.getName(),
			HowtoPlayActivity.class.getName(),
			SelectSongActivity.class.getName(), TopActivity.class.getName() };

	public DBStore(Context context) {
		this.context = context;
		sharedPreferences = this.context.getSharedPreferences("DBStore", 0);
	}

	public long getLastTime() {
		return sharedPreferences.getLong("LastTime", -1);
	}

	public void setLatTime(long l) {
		sharedPreferences.edit().putLong("LastTime", l);
	}

	public String getDate() {
		Date date = new Date(System.currentTimeMillis());
		return (date.getYear() + 1900) + ""
				+ (((date.getMonth() < 10) ? "0" : "") + date.getMonth()) + ""
				+ (((date.getDay() < 10) ? "0" : "") + date.getDay());
	}
}